/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/********************************************************************************
 * Program Filename: Bookshelf_spawn.java
 * Author: Luong, Micheal
 * Date: 9/16/16
 * Description: This class is where all the searching occurs. This is where the
 *              2D array that stores the 25 books is printed and stored. That 
 *              means if player chose choice 1, it will go to method opt1 and 
 *              execute the code to search for the position. Morever, choice 2 
 *              coorelates with method opt2, which executes the code to search 
 *              for the book name.
 * Input: Keyboard
 * Output: Console
 ********************************************************************************/
package connect4_micheal_luong;

    import java.io.File;
    import java.io.FileInputStream;
    import java.io.FileNotFoundException;
    import java.io.IOException;
    import java.io.InputStream;
    import sun.audio.AudioPlayer;
    import sun.audio.AudioStream;

/**
 *
 * @author micheal
 */
public class Sound {
    public static AudioStream as;
    
    /****************************************************************************
     * Method: The method name is shelves
     * Description: This method is responsible for filling the 2d array with 
     *              String values, which represent 25 titles of books. Then it will 
     *              call another method to print out the bookcase.
     * Parameters: no parameters taken
     * Pre-Conditions: This is the first method that is called from the main class
     *                 when the player runs the game.
     * Post-Conditions: Afterwards, there will be a 2D array with 25 titles in their
     *                  respective positions.
     ****************************************************************************/
    public static void Init(int type) throws FileNotFoundException, IOException {
        if(type == 1) {
            InputStream in = new FileInputStream(new File("music/dropSound.wav"));
            AudioStream dropCounter = new AudioStream(in); 
            Sound.as = dropCounter;
        } else if(type == 2) {
            InputStream in = new FileInputStream(new File("music/notValid.wav"));
            AudioStream notValid = new AudioStream(in);
            Sound.as = notValid;
        } else if(type == 3) {
            InputStream in = new FileInputStream(new File("music/Win.wav"));
            AudioStream win = new AudioStream(in);
            Sound.as = win;
        } else if(type == 4) {
            InputStream in = new FileInputStream(new File("music/Lose.wav"));
            AudioStream lose = new AudioStream(in);
            Sound.as = lose;
        } else if(type == 5) {
            InputStream in = new FileInputStream(new File("music/music.wav"));
            AudioStream lose = new AudioStream(in);
            Sound.as = lose;
        }
    }
    
    /****************************************************************************
     * Method: The method name is shelves
     * Description: This method is responsible for filling the 2d array with 
     *              String values, which represent 25 titles of books. Then it will 
     *              call another method to print out the bookcase.
     * Parameters: no parameters taken
     * Pre-Conditions: This is the first method that is called from the main class
     *                 when the player runs the game.
     * Post-Conditions: Afterwards, there will be a 2D array with 25 titles in their
     *                  respective positions.
     ****************************************************************************/
    public void Start() {
        AudioPlayer.player.start (as);
    }
    
    /****************************************************************************
     * Method: The method name is shelves
     * Description: This method is responsible for filling the 2d array with 
     *              String values, which represent 25 titles of books. Then it will 
     *              call another method to print out the bookcase.
     * Parameters: no parameters taken
     * Pre-Conditions: This is the first method that is called from the main class
     *                 when the player runs the game.
     * Post-Conditions: Afterwards, there will be a 2D array with 25 titles in their
     *                  respective positions.
     ****************************************************************************/
    public void Stop() {
        AudioPlayer.player.stop (as);
    }
}
