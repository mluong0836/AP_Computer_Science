/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/********************************************************************************
 * Program Filename: Bookshelf_spawn.java
 * Author: Luong, Micheal
 * Date: 9/16/16
 * Description: This class is where all the searching occurs. This is where the
 *              2D array that stores the 25 books is printed and stored. That 
 *              means if player chose choice 1, it will go to method opt1 and 
 *              execute the code to search for the position. Morever, choice 2 
 *              coorelates with method opt2, which executes the code to search 
 *              for the book name.
 * Input: Keyboard
 * Output: Console
 ********************************************************************************/

package connect4_micheal_luong;

    import java.util.ArrayList;
    import java.util.Random;

/**
 *
 * @author dong
 */
public class Computer extends Grid {

    private int pCol, pRow;
    private boolean win = false;
    private static ArrayList<AiLocations> stored = new ArrayList();
    Random rand = new Random();

    /****************************************************************************
     * Method: The method name is shelves
     * Description: This method is responsible for filling the 2d array with 
     *              String values, which represent 25 titles of books. Then it will 
     *              call another method to print out the bookcase.
     * Parameters: no parameters taken
     * Pre-Conditions: This is the first method that is called from the main class
     *                 when the player runs the game.
     * Post-Conditions: Afterwards, there will be a 2D array with 25 titles in their
     *                  respective positions.
     ****************************************************************************/
    public int getpRow() {
        return pRow;
    }

    /****************************************************************************
     * Method: The method name is shelves
     * Description: This method is responsible for filling the 2d array with 
     *              String values, which represent 25 titles of books. Then it will 
     *              call another method to print out the bookcase.
     * Parameters: no parameters taken
     * Pre-Conditions: This is the first method that is called from the main class
     *                 when the player runs the game.
     * Post-Conditions: Afterwards, there will be a 2D array with 25 titles in their
     *                  respective positions.
     ****************************************************************************/
    public void setpRow(int pRow) {
        this.pRow = pRow;
    }

    public Computer() {

    }

    /****************************************************************************
     * Method: The method name is shelves
     * Description: This method is responsible for filling the 2d array with 
     *              String values, which represent 25 titles of books. Then it will 
     *              call another method to print out the bookcase.
     * Parameters: no parameters taken
     * Pre-Conditions: This is the first method that is called from the main class
     *                 when the player runs the game.
     * Post-Conditions: Afterwards, there will be a 2D array with 25 titles in their
     *                  respective positions.
     ****************************************************************************/
    public void AiTurn() {//uses player's relative coorelation
        int randomize = 0;
        int tempHolder = 0;
        if (this.pCol-- >= 0) {
            stored.add(new AiLocations(pCol - 1));
        }
        if (this.pCol++ <= 6) {
            stored.add(new AiLocations(pCol + 1));
        }
        stored.add(new AiLocations(pCol));
        boolean loop = true;
        while (loop) {
            if (stored.isEmpty()) {
                tempHolder = rand.nextInt(7);
                while (!BorderCheck(tempHolder)) {
                    tempHolder = rand.nextInt(7);
                }
                System.out.println(tempHolder);
                UpdateBoard(2, tempHolder);
                loop = false;
            } else {
                randomize = rand.nextInt(stored.size());
                System.out.println(stored.get(randomize).getCol());
                if (BorderCheck(stored.get(randomize).getCol())) {
                    UpdateBoard(2, stored.get(randomize).getCol());
                    loop = false;
                } else {
                    System.out.println("deleted");
                    stored.remove(randomize);
                }
            }
        }
        stored.clear();
    }

    /****************************************************************************
     * Method: The method name is shelves
     * Description: This method is responsible for filling the 2d array with 
     *              String values, which represent 25 titles of books. Then it will 
     *              call another method to print out the bookcase.
     * Parameters: no parameters taken
     * Pre-Conditions: This is the first method that is called from the main class
     *                 when the player runs the game.
     * Post-Conditions: Afterwards, there will be a 2D array with 25 titles in their
     *                  respective positions.
     ****************************************************************************/
    public int getpCol() {
        return pCol;
    }

    /****************************************************************************
     * Method: The method name is shelves
     * Description: This method is responsible for filling the 2d array with 
     *              String values, which represent 25 titles of books. Then it will 
     *              call another method to print out the bookcase.
     * Parameters: no parameters taken
     * Pre-Conditions: This is the first method that is called from the main class
     *                 when the player runs the game.
     * Post-Conditions: Afterwards, there will be a 2D array with 25 titles in their
     *                  respective positions.
     ****************************************************************************/
    public void setpCol(int pCol) {
        this.pCol = pCol;
    }

    /****************************************************************************
     * Method: The method name is shelves
     * Description: This method is responsible for filling the 2d array with 
     *              String values, which represent 25 titles of books. Then it will 
     *              call another method to print out the bookcase.
     * Parameters: no parameters taken
     * Pre-Conditions: This is the first method that is called from the main class
     *                 when the player runs the game.
     * Post-Conditions: Afterwards, there will be a 2D array with 25 titles in their
     *                  respective positions.
     ****************************************************************************/
    public boolean isWin() {
        return win;
    }

    /****************************************************************************
     * Method: The method name is shelves
     * Description: This method is responsible for filling the 2d array with 
     *              String values, which represent 25 titles of books. Then it will 
     *              call another method to print out the bookcase.
     * Parameters: no parameters taken
     * Pre-Conditions: This is the first method that is called from the main class
     *                 when the player runs the game.
     * Post-Conditions: Afterwards, there will be a 2D array with 25 titles in their
     *                  respective positions.
     ****************************************************************************/
    public void setWin(boolean win) {
        this.win = win;
    }
}
