/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/********************************************************************************
 * Program Filename: Bookshelf_spawn.java
 * Author: Luong, Micheal
 * Date: 9/16/16
 * Description: This class is where all the searching occurs. This is where the
 *              2D array that stores the 25 books is printed and stored. That 
 *              means if player chose choice 1, it will go to method opt1 and 
 *              execute the code to search for the position. Morever, choice 2 
 *              coorelates with method opt2, which executes the code to search 
 *              for the book name.
 * Input: Keyboard
 * Output: Console
 ********************************************************************************/

package connect4_micheal_luong;

    import java.io.IOException;

/**
 *
 * @author dong
 */
public class Grid {

    static int[][] board = new int[6][7];
    static Player player = new Player();
    static Computer ai = new Computer();
    static boolean[] first = {false, false, false, false, false, false, false};
    static Sound effect = new Sound();
    
    public void init() {
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board.length; j++) {
                if (i == board.length - 1) {
                    board[i][j] = 5;//this represents the starting row
                } else {
                    board[i][j] = 0;//this represents the empty spots to fall through
                }
            }
        }
        
        for(int i = 0; i < first.length; i++) {
            first[i] = false;
        }
    }

    /****************************************************************************
     * Method: The method name is shelves
     * Description: This method is responsible for filling the 2d array with 
     *              String values, which represent 25 titles of books. Then it will 
     *              call another method to print out the bookcase.
     * Parameters: no parameters taken
     * Pre-Conditions: This is the first method that is called from the main class
     *                 when the player runs the game.
     * Post-Conditions: Afterwards, there will be a 2D array with 25 titles in their
     *                  respective positions.
     ****************************************************************************/
    public boolean BorderCheck(int col) {
        boolean valid = false;
        
        if (col >= 0 && col <= 6) {
            valid = board[0][col] == 0;//returns true if the space is open
        }
        return valid;
    }

    /****************************************************************************
     * Method: The method name is shelves
     * Description: This method is responsible for filling the 2d array with 
     *              String values, which represent 25 titles of books. Then it will 
     *              call another method to print out the bookcase.
     * Parameters: no parameters taken
     * Pre-Conditions: This is the first method that is called from the main class
     *                 when the player runs the game.
     * Post-Conditions: Afterwards, there will be a 2D array with 25 titles in their
     *                  respective positions.
     ****************************************************************************/
    public void UpdateBoard(int playerType, int col) {
        int tempRow = 0;
        for (int row = 0; row < board.length; row++) {
            if (board[row][col] != 0) {
                if (first[col]) {
                    board[row - 1][col] = playerType;
                    tempRow = row - 1;
                } else {
                    board[row][col] = playerType;
                    first[col] = true;
                    tempRow = row;
                }
                ai.setpRow(tempRow);
                ai.setpCol(col);
                return;
            }
        }
    }

    /****************************************************************************
     * Method: The method name is shelves
     * Description: This method is responsible for filling the 2d array with 
     *              String values, which represent 25 titles of books. Then it will 
     *              call another method to print out the bookcase.
     * Parameters: no parameters taken
     * Pre-Conditions: This is the first method that is called from the main class
     *                 when the player runs the game.
     * Post-Conditions: Afterwards, there will be a 2D array with 25 titles in their
     *                  respective positions.
     ****************************************************************************/
    public void Display() {
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board.length; j++) {
                if (board[i][j] == 0 || board[i][j] == 5) {//empty spots
                    System.out.print(TextColor.WHITE + "|🔴|" + TextColor.RESET);
                } else if (board[i][j] == 1) {//player counters
                    System.out.print(TextColor.RED + "|🔴|" + TextColor.RESET);
                } else if (board[i][j] == 2) {//ai counters
                    System.out.print(TextColor.BLUE + "|🔴|" + TextColor.RESET);
                } else if (board[i][j] == 3) {//winning counters
                    System.out.print(TextColor.YELLOW + "|🔴|" + TextColor.RESET);
                }
            }
            System.out.println("");
        }
        
        for(int i = 0; i < 5; i++) {
            System.out.println("");
        }
    }

    /****************************************************************************
     * Method: The method name is shelves
     * Description: This method is responsible for filling the 2d array with 
     *              String values, which represent 25 titles of books. Then it will 
     *              call another method to print out the bookcase.
     * Parameters: no parameters taken
     * Pre-Conditions: This is the first method that is called from the main class
     *                 when the player runs the game.
     * Post-Conditions: Afterwards, there will be a 2D array with 25 titles in their
     *                  respective positions.
     ****************************************************************************/
    public boolean CheckWin(int player) {
        boolean valid = false;

        //horizontal check
        for (int row = 0; row < board.length; row++) {
            for (int col = 0; col < board[0].length - 3; col++) {
                if (board[row][col] == player
                        && board[row][col + 1] == player
                        && board[row][col + 2] == player
                        && board[row][col + 3] == player) {
                    valid = true;
                    board[row][col] = 3;
                    board[row][col+1] = 3;
                    board[row][col+2] = 3;
                    board[row][col+3] = 3;
                    return true;
                }
            }            
        }

        //vertical check
        for (int row = 0; row < board.length - 3; row++) {
            for (int col = 0; col < board[0].length; col++) {
                if (board[row][col] == player
                        && board[row + 1][col] == player
                        && board[row + 2][col] == player
                        && board[row + 3][col] == player) {
                    valid = true;
                    board[row][col] = 3;
                    board[row + 1][col] = 3;
                    board[row + 2][col] = 3;
                    board[row + 3][col] = 3;
                    return true;
                }
            }
        }

        //check upward diagonal
        for (int row = 3; row < board.length; row++) {
            for (int col = 0; col < board[0].length - 3; col++) {
                if (board[row][col] == player
                        && board[row - 1][col + 1] == player
                        && board[row - 2][col + 2] == player
                        && board[row - 3][col + 3] == player) {
                    valid = true;
                    board[row][col] = 3;
                    board[row - 1][col + 1] = 3;
                    board[row - 2][col + 2] = 3;
                    board[row - 3][col + 3] = 3;
                    return true;
                }
            }
        }

        //check downward diagonal
        for (int row = 0; row < board.length - 3; row++) {
            for (int col = 0; col < board[0].length - 3; col++) {
                if (board[row][col] == player
                        && board[row + 1][col + 1] == player
                        && board[row + 2][col + 2] == player
                        && board[row + 3][col + 3] == player) {
                    valid = true;
                    board[row][col] = 3;
                    board[row + 1][col + 1] = 3;
                    board[row + 2][col + 2] = 3;
                    board[row + 3][col + 3] = 3;
                    return true;
                }
            }
        }
        return valid;
    }

    /****************************************************************************
     * Method: The method name is shelves
     * Description: This method is responsible for filling the 2d array with 
     *              String values, which represent 25 titles of books. Then it will 
     *              call another method to print out the bookcase.
     * Parameters: no parameters taken
     * Pre-Conditions: This is the first method that is called from the main class
     *                 when the player runs the game.
     * Post-Conditions: Afterwards, there will be a 2D array with 25 titles in their
     *                  respective positions.
     ****************************************************************************/
    public void GamePlay() throws IOException {

        boolean continues = true;
        Display();
        while (continues) {
            player.pTurn();
            Sound.Init(1);
            effect.Start();
            Display();
            if (CheckWin(1)) {//checks player's counters
                Connect4_Micheal_Luong.pwin++;
                Display();
                Sound.Init(3);
                effect.Start();
                return;
            }

            ai.AiTurn();
            Sound.Init(1);
            effect.Start();
            if (CheckWin(2)) {//checks ai's counters
                Connect4_Micheal_Luong.cwin++;
                Sound.Init(4);
                effect.Start();
                Display();
                return;
            }
            Display();
        }
    }
}
