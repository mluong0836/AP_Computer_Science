/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/********************************************************************************
 * Program Filename: Bookshelf_spawn.java
 * Author: Luong, Micheal
 * Date: 9/16/16
 * Description: This class is where all the searching occurs. This is where the
 *              2D array that stores the 25 books is printed and stored. That 
 *              means if player chose choice 1, it will go to method opt1 and 
 *              execute the code to search for the position. Morever, choice 2 
 *              coorelates with method opt2, which executes the code to search 
 *              for the book name.
 * Input: Keyboard
 * Output: Console
 ********************************************************************************/
package connect4_micheal_luong;

/**
 *
 * @author micheal
 */
public class AnsiArt {

    /****************************************************************************
     * Method: The method name is shelves
     * Description: This method is responsible for filling the 2d array with 
     *              String values, which represent 25 titles of books. Then it will 
     *              call another method to print out the bookcase.
     * Parameters: no parameters taken
     * Pre-Conditions: This is the first method that is called from the main class
     *                 when the player runs the game.
     * Post-Conditions: Afterwards, there will be a 2D array with 25 titles in their
     *                  respective positions.
     ****************************************************************************/
    public void Win() {
        System.out.println(TextColor.GREEN + " __        _____ _   _ \n" + TextColor.RESET
                + TextColor.GREEN + " \\ \\      / /_ _| \\ | |\n" + TextColor.RESET
                + TextColor.GREEN + "  \\ \\ /\\ / / | ||  \\| |\n" + TextColor.RESET
                + TextColor.GREEN + "   \\ V  V /  | || |\\  |\n" + TextColor.RESET
                + TextColor.GREEN + "    \\_/\\_/  |___|_| \\_|\n" + TextColor.RESET
                + TextColor.GREEN + "                       " + TextColor.RESET);
    }

    /****************************************************************************
     * Method: The method name is shelves
     * Description: This method is responsible for filling the 2d array with 
     *              String values, which represent 25 titles of books. Then it will 
     *              call another method to print out the bookcase.
     * Parameters: no parameters taken
     * Pre-Conditions: This is the first method that is called from the main class
     *                 when the player runs the game.
     * Post-Conditions: Afterwards, there will be a 2D array with 25 titles in their
     *                  respective positions.
     ****************************************************************************/
    public void Lose() {
        System.out.println(TextColor.RED + "  _     ___  ____  _____ \n" + TextColor.RESET
                + TextColor.RED + " | |   / _ \\/ ___|| ____|\n" + TextColor.RESET
                + TextColor.RED + " | |  | | | \\___ \\|  _|  \n" + TextColor.RESET
                + TextColor.RED + " | |__| |_| |___) | |___ \n" + TextColor.RESET
                + TextColor.RED + " |_____\\___/|____/|_____|\n" + TextColor.RESET
                + TextColor.RED + "                         " + TextColor.RESET);
    }

    /****************************************************************************
     * Method: The method name is shelves
     * Description: This method is responsible for filling the 2d array with 
     *              String values, which represent 25 titles of books. Then it will 
     *              call another method to print out the bookcase.
     * Parameters: no parameters taken
     * Pre-Conditions: This is the first method that is called from the main class
     *                 when the player runs the game.
     * Post-Conditions: Afterwards, there will be a 2D array with 25 titles in their
     *                  respective positions.
     ****************************************************************************/
    public void Player() {
        System.out.println(TextColor.PURPLE + "    ____  __                         \n" + TextColor.RESET
                + TextColor.PURPLE + "   / __ \\/ /___ ___  _____  _____    \n" + TextColor.RESET
                + TextColor.PURPLE + "  / /_/ / / __ `/ / / / _ \\/ ___/    \n" + TextColor.RESET
                + TextColor.PURPLE + " / ____/ / /_/ / /_/ /  __/ /        \n" + TextColor.RESET
                + TextColor.PURPLE + "/_/   /_/\\__,_/\\__, /\\___/_/         \n" + TextColor.RESET
                + TextColor.PURPLE + "              /____/                 " + TextColor.RESET);
    }

    /****************************************************************************
     * Method: The method name is shelves
     * Description: This method is responsible for filling the 2d array with 
     *              String values, which represent 25 titles of books. Then it will 
     *              call another method to print out the bookcase.
     * Parameters: no parameters taken
     * Pre-Conditions: This is the first method that is called from the main class
     *                 when the player runs the game.
     * Post-Conditions: Afterwards, there will be a 2D array with 25 titles in their
     *                  respective positions.
     ****************************************************************************/
    public void Computer() {
        System.out.println(TextColor.CYAN + "    ___    ____   \n" + TextColor.RESET
                + TextColor.CYAN + "   /   |  /  _/   \n" + TextColor.RESET
                + TextColor.CYAN + "  / /| |  / /     \n" + TextColor.RESET
                + TextColor.CYAN + " / ___ |_/ /      \n" + TextColor.RESET
                + TextColor.CYAN + "/_/  |_/___/      \n" + TextColor.RESET
                + TextColor.CYAN + "                  " + TextColor.RESET);
    }

    /****************************************************************************
     * Method: The method name is shelves
     * Description: This method is responsible for filling the 2d array with 
     *              String values, which represent 25 titles of books. Then it will 
     *              call another method to print out the bookcase.
     * Parameters: no parameters taken
     * Pre-Conditions: This is the first method that is called from the main class
     *                 when the player runs the game.
     * Post-Conditions: Afterwards, there will be a 2D array with 25 titles in their
     *                  respective positions.
     ****************************************************************************/
    public void PointSystem(int points) {
        if (points == 0) {
            System.out.println(TextColor.YELLOW + "   ____ \n" + TextColor.RESET
                    + TextColor.YELLOW + "  / __ \\\n" + TextColor.RESET
                    + TextColor.YELLOW + " / / / /\n" + TextColor.RESET
                    + TextColor.YELLOW + "/ /_/ / \n" + TextColor.RESET
                    + TextColor.YELLOW + "\\____/  \n" + TextColor.RESET
                    + TextColor.YELLOW + "        " + TextColor.RESET);
        } else if (points == 1) {
            System.out.println(TextColor.YELLOW + " ____  \n" + TextColor.RESET
                    + TextColor.YELLOW + "|    | \n" + TextColor.RESET
                    + TextColor.YELLOW + " |   | \n" + TextColor.RESET
                    + TextColor.YELLOW + " |   | \n" + TextColor.RESET
                    + TextColor.YELLOW + " |   | \n" + TextColor.RESET
                    + TextColor.YELLOW + " |   | \n" + TextColor.RESET
                    + TextColor.YELLOW + " |___| " + TextColor.RESET);
        } else if (points == 2) {
            System.out.println(TextColor.YELLOW + " _______ \n" + TextColor.RESET
                    + TextColor.YELLOW + "|       |\n" + TextColor.RESET
                    + TextColor.YELLOW + "|____   |\n" + TextColor.RESET
                    + TextColor.YELLOW + " ____|  |\n" + TextColor.RESET
                    + TextColor.YELLOW + "| ______|\n" + TextColor.RESET
                    + TextColor.YELLOW + "| |_____ \n" + TextColor.RESET
                    + TextColor.YELLOW + "|_______|" + TextColor.RESET);
        }
    }
}
