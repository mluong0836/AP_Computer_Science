/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/********************************************************************************
 * Program Filename: Bookshelf_spawn.java
 * Author: Luong, Micheal
 * Date: 9/16/16
 * Description: This class is where all the searching occurs. This is where the
 *              2D array that stores the 25 books is printed and stored. That 
 *              means if player chose choice 1, it will go to method opt1 and 
 *              execute the code to search for the position. Morever, choice 2 
 *              coorelates with method opt2, which executes the code to search 
 *              for the book name.
 * Input: Keyboard
 * Output: Console
 ********************************************************************************/

package connect4_micheal_luong;

    import java.io.IOException;
    import java.util.Scanner;

/**
 *
 * @author dong
 */
public class Connect4_Micheal_Luong {

    /**
     * @param args the command line arguments
     */
    
    public static int counter = 0;
    public static int pwin, cwin;
    static Grid grid = new Grid();
    static AnsiArt text = new AnsiArt();
    
    public static void main(String[] args) throws IOException, InterruptedException {
        // TODO code application logic here
        Sound sound = new Sound();
        Sound.Init(5);
        sound.Start();
        grid.init();
        boolean outerloop = true;
        Scanner scan = new Scanner(System.in);
        int answer;
        while (outerloop) {
            System.out.println("What would you like to do?");
            System.out.println("(1) Play a game of Connect 4.");
            System.out.println("(2) Play best 2 out of 3.");
            System.out.println("(3) Read the rule book.");
            System.out.println("(4) Quit");
            answer = scan.nextInt();
            
            if(answer == 1) {
                sound.Stop();
                System.out.println("Let the games begin...");
                grid.GamePlay();
                grid.init();
            } else if(answer == 2) {
                sound.Stop();
                System.out.println("Let's start.");
                System.out.println("Whoever wins 2 games will be the winner.");
                boolean innerloop = true;
                while(innerloop) {
                    grid.GamePlay();
                    if(pwin == 2 || cwin == 2) {
                        innerloop = false;
                        if(pwin == 2) {
                            text.Player();
                            text.Win();
                        } else if(cwin == 2) {
                            text.Player();
                            text.Lose();
                        }
                    }
                    text.Player();
                    text.PointSystem(pwin);
                    text.Computer();
                    text.PointSystem(cwin);
                    grid.init();
                }
            } else if(answer == 3) {
                System.out.println("Player opens the rule book and begins reading...");
                Rules();
            } else if(answer == 4) {
                sound.Stop();
                System.out.println("Thank you for playing!");
                outerloop = false;
                System.exit(0);
            } else {
                System.out.println("I don't understand your response.");
            }
        }
    }
    
    /****************************************************************************
     * Method: The method name is shelves
     * Description: This method is responsible for filling the 2d array with 
     *              String values, which represent 25 titles of books. Then it will 
     *              call another method to print out the bookcase.
     * Parameters: no parameters taken
     * Pre-Conditions: This is the first method that is called from the main class
     *                 when the player runs the game.
     * Post-Conditions: Afterwards, there will be a 2D array with 25 titles in their
     *                  respective positions.
     ****************************************************************************/
    private static void Rules() throws InterruptedException {
        for(int i = 0; i < 15; i++) {
            System.out.print(TextColor.GREEN + "." + TextColor.RESET);
            Thread.sleep(1000);
        }
        System.out.println("");
        System.out.println("Hello...");
        Thread.sleep(2000);
        System.out.println("The objective of Connect 4 is to connect 4 of your own counters in a row.");
        Thread.sleep(2000);
        System.out.println("This can be done ");
        Thread.sleep(2000);
        System.out.println("Vertically");
        Thread.sleep(2000);
        System.out.println("Horizontally");
        Thread.sleep(2000);
        System.out.println("or Diagonally");
        Thread.sleep(2000);
        System.out.println("Each player takes there turn to drop their counters in one of the 7 columns.");
        Thread.sleep(3000);
        System.out.println("You are to block your opponents linked 4 while trying to link 4 of yours.");
        Thread.sleep(3000);
        System.out.println("Good Luck!!!");
        Thread.sleep(1000);
    } 
}
