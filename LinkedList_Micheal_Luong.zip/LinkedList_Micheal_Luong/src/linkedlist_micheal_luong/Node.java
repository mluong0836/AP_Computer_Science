/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/********************************************************************************
 * Program Filename: Animal.java
 * Author: Luong, Micheal
 * Date: 
 * Description: 
 * Input: 
 * Output: 
 ********************************************************************************/

package linkedlist_micheal_luong;

/**
 *
 * @author micheal
 */
public class Node {
    Node next = null;
    int data;
    Character character;
    
    public Node(Character d) {
        character = d;
    }
}