/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/********************************************************************************
 * Program Filename: FossilRelative.java
 * Author: Luong, Micheal
 * Date: 11/8/16
 * Description: 
 * Input: Keyboard, ZooAnimal.java, Animal.java, LingerLing.java
 * Output: Zoo.java
 ********************************************************************************/

package cryptozoo_micheal_luong;

/**
 *
 * @author micheal
 */
public class FossilRelative extends LingerLing {
    
    public FossilRelative(String name, String origin, int dangerRate, boolean onTour) {
        super(name, origin, dangerRate, onTour);
    }
    
    public int FoodperWeek() {
        return 1;
    }
    
}
