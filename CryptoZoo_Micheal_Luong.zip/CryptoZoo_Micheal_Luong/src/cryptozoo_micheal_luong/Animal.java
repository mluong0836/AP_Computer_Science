/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/********************************************************************************
 * Program Filename: Animal.java
 * Author: Luong, Micheal
 * Date: 11/3/16
 * Description: 
 * Input: Keyboard, ZooAnimal.java
 * Output: Zoo.java, LingLing.java, Mythical.java, FossilRelative.java, and
 *         Paranormal.java
 ********************************************************************************/

package cryptozoo_micheal_luong;

/**
 *
 * @author micheal
 */
public abstract class Animal implements ZooAnimal{
    String name;
    String origin;
    int dangerRating;
    boolean ontour;
    
    public Animal(String Name, String Origin, int DangerRating, boolean onTour) {
        this.name = Name;
        this.origin = Origin;
        this.dangerRating = DangerRating;
        this.ontour = onTour;
    }
    
    @Override
    public String toString() {
        return "Name: " + this.name + "\n" +
                "Origin: " + this.origin + "\n" +
                "Danger Rating: " + this.dangerRating + "\n";
    }
    
    abstract int FoodperWeek();
}
