/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/********************************************************************************
 * Program Filename: LingerLing.java
 * Author: Luong, Micheal
 * Date: 11/4/16
 * Description: 
 * Input: Keyboard, Animal.java, ZooAnimal.java
 * Output: Zoo.java, FossilRelative.java
 ********************************************************************************/

package cryptozoo_micheal_luong;

/**
 *
 * @author micheal
 */
public class LingerLing extends Animal {
    
    public LingerLing(String name, String origin, int dangerRate, boolean onTour) {
        super(name, origin, dangerRate, onTour);
    }
    
    @Override
    public String getFoodType() {
        return "none";
    }
    
    @Override
    public void setFoodType(String food) {
        
    }
    
    @Override
    public int getFoodamt() {
        return 0;
    }
    
    @Override 
    public void setFoodamt(int foodtype) {
        
    }
    
    @Override
    public int FoodperWeek() {
        return 1;
    }
    
}
