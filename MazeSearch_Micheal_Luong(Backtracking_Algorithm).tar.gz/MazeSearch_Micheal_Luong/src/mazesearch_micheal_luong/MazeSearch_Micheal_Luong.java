/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mazesearch_micheal_luong;

/**
 *
 * @author dong
 */
public class MazeSearch_Micheal_Luong {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Maze.main(args);
        //m.generateMaze();
        /*Maze labyrinth = new Maze();
      
        labyrinth.print_maze();

        if (labyrinth.solve(0, 0))
            System.out.println ("Maze solved!");
        else
            System.out.println ("No solution.");

        labyrinth.print_maze();*/

    }  // method main
}
