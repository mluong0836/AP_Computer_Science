/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package micheal_luong_bit_parity_check;

import java.util.Scanner;
import java.util.*;

/**
 *
 * @author micheal
 */
public class Micheal_Luong_Bit_Parity_Check {

    /**
     * @param args the command line arguments
     */
    public static String[] Name;

    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        String answer;
        System.out.println("What is your first name?");
        answer = scan.nextLine();
        Response(answer);
        int[][] results = HammingCode(Name);
        for(int i = 0; i < results.length; i++) {
            for(int j = 0; j < 7; j++) {
                System.out.println(results[i][j]);
            }
        }
//        for (int i = 0; i < Name.length; i++) {
//            System.out.println(Name[i]);
//        }
//        System.out.println(Name.length);
    }

    static void Response(String response) {

        Name = new String[response.length()];

        /**********************************************
        NOTE: use a 2 d array here and change back to int
        * because now there are separate digits to work with
         * *********************************************/   
        for (int i = 0; i < response.length(); i++) {
            char letter = response.charAt(i);
            String asciiValue = Integer.toBinaryString(letter);
            System.out.println(asciiValue.length());
            //Name[i] = Integer.parseInt(asciiValue);
            Name[i] = asciiValue;
        }

        System.out.println("\n\n\n\n");
    }

    static int[][] HammingCode(String[] original) {
        /**
         * **********************************************************
         * NOTE: This has to include all 7 letters
         * **********************************************************
         */
        int[][] clone = new int[13][7];
        int counter = 0;
        int[] parity = new int[4];//holds the parity so they don't conflict

        /*setting up parity bits references same letter for original[i]*/
        for (int i = 0; i < clone.length; i++) {
            clone[i][0] = Integer.parseInt(original[i].substring(0, 1)) ^ Integer.parseInt(original[i].substring(1, 2))
                    ^ Integer.parseInt(original[i].substring(3, 4)) ^ Integer.parseInt(original[i].substring(4, 5))
                    ^ Integer.parseInt(original[i].substring(5, 6));
            //clone[i] = original[0] ^ original[1] ^ original[3] ^ original[4] ^ original[6];
            clone[i][1] = Integer.parseInt(original[i].substring(0, 1)) ^ Integer.parseInt(original[i].substring(2, 3))
                    ^ Integer.parseInt(original[i].substring(5, 6)) ^ Integer.parseInt(original[i].substring(6, 7));
            //clone[1]= original[0] ^ original[2] ^ original[3] ^ original[5] ^ original[6];
            clone[i][3] = Integer.parseInt(original[i].substring(1, 2)) ^ Integer.parseInt(original[i].substring(2, 3))
                    ^ Integer.parseInt(original[i].substring(3, 4));
            //clone[3] = original[1] ^ original[2] ^ original[3];
            clone[i][7] = Integer.parseInt(original[i].substring(4, 5)) ^ Integer.parseInt(original[i].substring(5, 6))
                    ^ Integer.parseInt(original[i].substring(6, 6));
            //clone[7] = original[4] ^ original[5] ^ original[6];
        }
        for (int i = 0; i < clone.length; i++) {//iterates through each letter
            for (int j = 0; j < original[i].length(); j++) {//iterate through the bits
                if (i != 0 && i != 1 && i != 3 && i != 7) {
                    clone[i][j] = Integer.parseInt(original[i].substring(j, j+1));//ight get out of bounds here
                }
            }
        }
        
        return clone;
    }
}
