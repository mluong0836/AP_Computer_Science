/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/********************************************************************************
 * Program Filename: Zoo.java
 * Author: Luong, Micheal
 * Date: 11/9/16
 * Description: This class will add objects to the arraylist as well as create
 *              new objects based on what the player wants. In addition, this 
 *              class also holds methods responsible for determining if an animal
 *              is or is not on tour.
 * Input: Keyboard, Animal.java, CryptoZoo_Micheal_Luong.java
 * Output: CryptoZoo_Micheal_Luong.java
 ********************************************************************************/

package cryptozoo_micheal_luong;
    import java.util.*;

/**
 *
 * @author micheal
 */

public class Zoo {
    static ArrayList<Animal> zooList = new ArrayList();//arraylist of animal objects   
    static int counter = 1;//use for indexing through the array when searching for an animal
    
    /****************************************************************************
     * Method: list()
     * Description: This method is responsible for creating and adding the default
     *              animal objects. 
     * Parameters: none
     * Pre-Conditions: When you start the game.
     * Post-Conditions: You will have an arraylist filled with Mythical, Paranormal,
     *                  LingerLing, and FossilRelative objects.
     ****************************************************************************/
    
    public void list() {
        Mythical myth1 = new Mythical("Unicorn", "over the rainbow", 4, false, true, 0, 0, "hay", 2);
        zooList.add(myth1);//adds the object
        Mythical myth2 = new Mythical("Reindeer", "the North Pole", 2, false, true, 4, 5, "berries", 15);
        zooList.add(myth2);
        Mythical myth3 = new Mythical("Dragons", "Mount Etna", 10, false, true, 6, 7, "raw pork", 50);
        zooList.add(myth3);
        Paranormal para1 = new Paranormal("Yeti", "The Himalyayas", 7, false, true,  9, 7);
        zooList.add(para1);
        Paranormal para2 = new Paranormal("Three-headed goat", "African Savanna", 2, false, true, 1, 4);
        zooList.add(para2);
        Paranormal para3 = new Paranormal("Bigfoot", "Dense Forests", 5, false, true,  4,7);
        zooList.add(para3);
        LingerLing ling1 = new LingerLing("Woolly Mammoth", "Alaska", 6, false, 5, 3, true);
        zooList.add(ling1);
        LingerLing ling2 = new LingerLing("Saber-tooth", "Antartica", 10, false, 2, 4, true);
        zooList.add(ling2);
        LingerLing ling3 = new LingerLing("Tasmanian Tiger", "Tansmania", 8, false, 8, 3, true);
        zooList.add(ling3);
        FossilRelative fos1 = new FossilRelative("Pelycosaur", "Egypt", 1, false, 7 , 2, true);
        zooList.add(fos1);
        FossilRelative fos2 = new FossilRelative("Tengu", "Japan", 2, false, 0, 4, true);
        zooList.add(fos2);
    }
    
    /****************************************************************************
     * Method: ShowAll()
     * Description: This method is responsible for iterating through the arrayList
     *              and printing out all the information of each animal.
     * Parameters: none
     * Pre-Conditions: The beginning of the game and everytime player chooses 
     *                  choice 6.
     * Post-Conditions: There will be a list of animals with information displayed
     *                  on the console.
     ****************************************************************************/
    public void ShowAll() {
        for(int i = 0; i < zooList.size(); i++) {
            System.out.println(zooList.get(i).toString());
            System.out.println("Food type: " + zooList.get(i).getFoodType());
            System.out.println("Amount of Food: " + zooList.get(i).getFoodamt() + " lbs.");
            System.out.println("______________________________________________________");
        }
    }
    
    /****************************************************************************
     * Method: ShowonTour()
     * Description: This method will iterate through the arrayList and find which
     *              objects have their boolean ontour set to true. If it's true
     *              then they will be displayed on the console screen.
     * Parameters: none
     * Pre-Conditions: When the player chooses to see all animals on tour.
     * Post-Conditions: All animals that have the boolean onTour set to true will
     *                  be shown. 
     ****************************************************************************/
    
    public void ShowonTour() {
        for(int i = 0; i < zooList.size(); i++) {
            if(zooList.get(i).ontour) {
                System.out.println(zooList.get(i).toString());
                System.out.println("Food type: " + zooList.get(i).getFoodType());
                System.out.println("Amount of Food: " + zooList.get(i).getFoodamt() + " lbs.");
                System.out.println("______________________________________________________");
            }
        }
    }
    
    /****************************************************************************
     * Method: ShowNotonTour()
     * Description: This method will iterate through the arrayList and find which
     *              objects have their boolean ontour set to false. If it's false
     *              then they will be displayed on the console screen.
     * Parameters: none
     * Pre-Conditions: When the player asks to display the animals not on tour 
     * Post-Conditions: All animals that have the boolean onTour set to false will
     *                  be shown. 
     ****************************************************************************/
    
    public void ShowNotonTour() {
        for(int i = 0; i < zooList.size(); i++) {
            if(!zooList.get(i).ontour) {
                System.out.println(zooList.get(i).toString());
                System.out.println("Food type: " + zooList.get(i).getFoodType());
                System.out.println("Amount of Food: " + zooList.get(i).getFoodamt() + " lbs.");
                System.out.println("______________________________________________________");
            }
        }
    }
    
    /****************************************************************************
     * Method: addnewAnimalsMythical()
     * Description: Creates new Mythical object by taking 5 parameters that was
     *              recorded in the main class when the series of questions were
     *              answered.
     * Parameters: String name, String origin, int DangerLevel, String foodtype,
     *             and int amount.
     * Pre-Conditions: When the player chooses to create a Mythical animal and
     *                 have answered all the questions that fill out all these
     *                 parameters.
     * Post-Conditions: A new Mythical object will be created and added to the 
     *                  ArrayList.
     ****************************************************************************/
    
    public void addnewAnimalsMythical(String name, String origin, int DangerLevel, String foodtype, int amount) {
        zooList.add(new Mythical(name, origin, DangerLevel, false, true, 0, 0, foodtype, amount));
    }
    
    /****************************************************************************
     * Method: addnewAnimalsParanormal()
     * Description: Creates new Paranormal object by taking 3 parameters that was
     *              recorded in the main class when the series of questions were
     *              answered.
     * Parameters: String name, String origin, int DangerLevel
     * Pre-Conditions: When the player chooses to create a Paranormal animal and
     *                 have answered all the questions that fill out all these
     *                 parameters.
     * Post-Conditions: A new Paranormal object will be created and added to the 
     *                  ArrayList.
     ****************************************************************************/
    
    public void addnewAnimalsParanormal(String name, String origin, int DangerLevel) {
        zooList.add(new Paranormal(name, origin, DangerLevel, false, true, 0, 0));
    }
    
    /****************************************************************************
     * Method: addnewAnimalsLingerLing()
     * Description: Creates new LingerLing object by taking 3 parameters that was
     *              recorded in the main class when the series of questions were
     *              answered.
     * Parameters: String name, String origin, int DangerLevel
     * Pre-Conditions: When the player chooses to create a LingerLing animal and
     *                 have answered all the questions that fill out all these
     *                 parameters.
     * Post-Conditions: A new LingerLing object will be created and added to the 
     *                  ArrayList.
     ****************************************************************************/
    
    public void addnewAnimalsLingerLing(String name, String origin, int DangerLevel) {
        zooList.add(new LingerLing(name, origin, DangerLevel, false, 0, 0, true));
    }
    
    /**********************************************************************************
     * Method: addnewAnimalsFossilRelative()
     * Description: Creates new Fossil Relative object by taking 3 parameters that was
     *              recorded in the main class when the series of questions were
     *              answered.
     * Parameters: String name, String origin, int DangerLevel
     * Pre-Conditions: When the player chooses to create a Fossile Relative animal and
     *                 have answered all the questions that fill out all these
     *                 parameters.
     * Post-Conditions: A new Fossil Relative object will be created and added to the 
     *                  ArrayList.
     ***********************************************************************************/
    
    public void addnewAnimalsFossilRelative(String name, String origin, int DangerLevel) {
        zooList.add(new FossilRelative(name, origin, DangerLevel, false, 0, 0, true));
    }
    
    /****************************************************************************
     * Method: Remove()
     * Description: This method will iterate through the arraylist to find the 
     *              name of the object that matches the passed parameter, which 
     *              encompasses the desired animal to be removed.
     * Parameters: String name 
     * Pre-Conditions: When the player chooses choice 2
     * Post-Conditions: The animal with that name will be removed.
     ****************************************************************************/
    
    public void Remove(String name) {
        boolean looping = true;
        if(zooList.isEmpty()) {
            System.out.println("There is no animal in your catalog to begin with...");
        } else {
            while(looping) {
                counter++;
                /*if the name matches the one passed by the parameter*/
                if(zooList.get(counter).name.equalsIgnoreCase(name)) {
                    zooList.remove(counter);//removes the object
                    counter = 0;
                    looping = false;//ends loop
                    System.out.println("The animal " + name + " has been removed.");
                }
            }
        }
    }
    
    /****************************************************************************
     * Method: MarkonTour()
     * Description: This method will iterate through the arraylist to find the 
     *              object with the name similar to the one provided by the passed
     *              parameter. Once it finds it, the boolean onTour will be set to
     *              true.
     * Parameters: String name
     * Pre-Conditions: When the player chooses choice 3
     * Post-Conditions: The particular animal with the associated name will have
     *                  boolean onTour set to true.
     ****************************************************************************/
    
    public void MarkonTour(String name) {
        for(int i = 0; i < zooList.size(); i++) {
            if(zooList.get(i).name.equalsIgnoreCase(name)) {
                zooList.get(i).ontour = true;//sets object boolean onTour to true
                System.out.println(name + " is marked out on tour.");
            }
        }
    }
}