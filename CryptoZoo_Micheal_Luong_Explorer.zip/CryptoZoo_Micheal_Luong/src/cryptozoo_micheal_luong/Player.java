/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/********************************************************************************
 * Program Filename: Player.java
 * Author: Luong, Micheal
 * Date: 11/13/16
 * Description: This class is responsible for holding the necessary methods, 
 *              variables, and class constructor to create a player object that 
 *              will influence and be influenced by the game play.
 * Input: Keyboard, Interactive_Game.java
 * Output: Interactive_Game.java, CryptoZoo_Micheal_Luong.java, Enemies.java
 ********************************************************************************/

package cryptozoo_micheal_luong;

/**
 *
 * @author micheal
 */

public class Player {
    private int RowLoc;//the y location
    private int ColLoc;//the x location
    private boolean dead;//boolean to end the interactive game play
    private String character;//the ascii character used to represent the player in the game
    private int level;//the player's level
    private int catches;//the number of catches
    
    /*Constructor to create a player object with the y,x coordinates, a boolean to determine if the player is dead/alive,
      an ascii character, the level, and the number of catches.*/
    public Player(int rowLoc, int ColLoc, boolean Dead, String ascii, int Level, int Catches) {
        this.RowLoc = rowLoc;
        this.ColLoc = ColLoc;
        this.dead = Dead;
        this.character = ascii;
        this.level = Level;
        this.catches = Catches;
    }
    
    public int getRowLoc() {
        return RowLoc;
    }

    public void setRowLoc(int RowLoc) {
        this.RowLoc = RowLoc;
    }

    public int getColLoc() {
        return ColLoc;
    }

    public void setColLoc(int ColLoc) {
        this.ColLoc = ColLoc;
    }

    public boolean isDead() {
        return dead;
    }

    public void setDead(boolean dead) {
        this.dead = dead;
    }

    public String getCharacter() {
        return character;
    }

    public void setCharacter(char String) {
        this.character = character;
    }
    
    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getCatches() {
        return catches;
    }

    public void setCatches(int catches) {
        this.catches = catches;
    }
    
    public void ScoreBoard() {
        System.out.println("Number of Catches: " + this.catches + ".");
        if(this.catches >= 3 && this.catches < 5) {
            this.level = 2;
        } else if(this.catches >= 5 && this.catches < 8) {
            this.level = 3;
        } else if(this.catches == 8) {
            this.level = 4;
        }
        System.out.println("Player Rank: " + this.level + ".");
    }
    
}
