/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/********************************************************************************
 * Program Filename: FossilRelative.java
 * Author: Luong, Micheal
 * Date: 11/8/16
 * Description: This class extends LingerLing class and will be the template to 
 *              create fossil relative animal objects.
 * Input: Keyboard, ZooAnimal.java, Animal.java, LingerLing.java
 * Output: Zoo.java
 ********************************************************************************/

package cryptozoo_micheal_luong;

/**
 *
 * @author micheal
 */
public class FossilRelative extends LingerLing {
    
    /*Class constructor that holds parameters of the super class parameters and the ontour boolean, the y,x coordinates, and a 
      boolean to determine if the animal is caught in the interactive game yet.*/
    public FossilRelative(String name, String origin, int dangerRate, boolean onTour, int enemRow, int enemCol, boolean alive) {
        super(name, origin, dangerRate, onTour, enemRow, enemCol, alive);
    }
    
    /*tells the player how much to feed per week*/
    public int FoodperWeek() {
        return 1;
    }
    
}