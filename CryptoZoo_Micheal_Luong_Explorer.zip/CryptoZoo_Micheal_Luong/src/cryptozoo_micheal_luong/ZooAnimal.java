/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/********************************************************************************
 * Program Filename: ZooAnimal.java
 * Author: Luong, Micheal
 * Date: 11/3/16
 * Description: This is an interface to hold the template methods of getFoodType,
 *              setFoodType(String food), getFoodamt, and setFoodamt(int amt)
 * Input: Keyboard
 * Output: Animal.java, LingerLing.java, Mythical.java, Paranormal.java, and
 *         FossilRelative.java
 ********************************************************************************/
package cryptozoo_micheal_luong;

/**
 *
 * @author micheal
 */
public interface ZooAnimal {
    
    public String getFoodType();
    public void setFoodType(String food);
    public int getFoodamt();
    public void setFoodamt(int amt);
}