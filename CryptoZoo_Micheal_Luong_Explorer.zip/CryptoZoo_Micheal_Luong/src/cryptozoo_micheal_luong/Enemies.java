/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/********************************************************************************
 * Program Filename: Enemies.java
 * Author: Luong, Micheal
 * Date: 11/13/16
 * Description: This is the Enemy class and will be responsible for making the 
 *              enemy interact with the player within the game mode.
 * Input: Keyboard, Interactive_Game.java, Player.java
 * Output: Interactive_Game.java
 ********************************************************************************/

package cryptozoo_micheal_luong;
    import java.util.*;

/**
 *
 * @author micheal
 */

public class Enemies extends Interactive_Game {
    static Random enems = new Random();
  
    public void EnemyMovements(int direction) {
        for(int i = 0; i < 10; i++) {
            if(direction == 0) {//player was moving north
                Zoo.zooList.get(i).enemyrow--;
                EnemBoundaries();
            } else if(direction == 1) {//player was moving south
                Zoo.zooList.get(i).enemyrow++;
                EnemBoundaries();
            } else if(direction == 2) {//player was moving west
                Zoo.zooList.get(i).enemcol--;
                EnemBoundaries();
            } else {//player was moving east
                Zoo.zooList.get(i).enemcol++;
                EnemBoundaries();
            }
        }
    }
    
    public void EnemBoundaries() {
        for(int j = 0; j < 10; j++) {
            
            if(Zoo.zooList.get(j).enemyrow >= 20 || Zoo.zooList.get(j).enemyrow < 0 || Zoo.zooList.get(j).enemcol >= 20 || Zoo.zooList.get(j).enemcol < 0) {
               
                Zoo.zooList.get(j).enemcol = enems.nextInt(19);
                Zoo.zooList.get(j).enemyrow = enems.nextInt(19);
            }
        }
    }
    
    public void Collisions(int PlayerY, int PlayerX) {
        for(int enemy = 0; enemy < 10; enemy++) {
            if(Zoo.zooList.get(enemy).enemyrow == PlayerY && Zoo.zooList.get(enemy).enemcol == PlayerX && Zoo.zooList.get(enemy).alive) {//a catch
                player.setCatches(player.getCatches()+1);//updates player catches
                Zoo.zooList.get(enemy).alive = false;
            } else if(Zoo.zooList.get(enemy).enemyrow == objects.get(0).obsY && Zoo.zooList.get(enemy).enemcol == objects.get(0).obsX) {
                player.setCatches(player.getCatches()+1);//updates player catches
                Zoo.zooList.get(enemy).alive = false;
                objects.get(0).triggered = false;
            } else if(Zoo.zooList.get(enemy).enemyrow == objects.get(1).obsY && Zoo.zooList.get(enemy).enemcol == objects.get(1).obsX) {
                player.setCatches(player.getCatches()+1);//updates player catches
                Zoo.zooList.get(enemy).alive = false;
                objects.get(1).triggered = false;
            } else if(Zoo.zooList.get(enemy).enemyrow == objects.get(2).obsY && Zoo.zooList.get(enemy).enemcol == objects.get(2).obsX) {
                Zoo.zooList.get(enemy).enemyrow = Zoo.zooList.get(enemy).enemyrow-1;
                Zoo.zooList.get(enemy).enemcol = Zoo.zooList.get(enemy).enemcol-1;
            } else if(Zoo.zooList.get(enemy).enemyrow == objects.get(3).obsY && Zoo.zooList.get(enemy).enemcol == objects.get(3).obsX) {
                Zoo.zooList.get(enemy).enemyrow = Zoo.zooList.get(enemy).enemyrow-1;
                Zoo.zooList.get(enemy).enemcol = Zoo.zooList.get(enemy).enemcol-1;
            }
        }
    }

}
