/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/********************************************************************************
 * Program Filename: Animal.java
 * Author: Luong, Micheal
 * Date: 11/3/16
 * Description: This is an abstract class served as a template so the other 
 *              classes can use. The constructor holds 3 necesssary variables.
 * Input: Keyboard, ZooAnimal.java
 * Output: Zoo.java, LingLing.java, Mythical.java, FossilRelative.java, and
 *         Paranormal.java
 ********************************************************************************/

package cryptozoo_micheal_luong;

/**
 *
 * @author micheal
 */

public abstract class Animal implements ZooAnimal{
    String name;//animal name template
    String origin;//animal origin template
    int dangerRating;//animal danger rating template
    int enemyrow;//animal y location 
    int enemcol;//animal x location
    boolean ontour;//boolean to see if it is on tour template
    boolean alive;//boolean to determine if animal is caught during the interactive gameplay
    
    /*class constructor that will hold the basic features of all animals like the name, origin, dangerrating, if its on tour,
      it's x coordinate, it's y coordinate, and if it is caught or not*/
    public Animal(String Name, String Origin, int DangerRating, boolean onTour, int enemRow, int enemCol, boolean alive) {
        this.name = Name;
        this.origin = Origin;
        this.dangerRating = DangerRating;
        this.ontour = onTour;
        this.enemyrow = enemRow;
        this.enemcol = enemCol;
        this.alive = alive;
    }
    
    /****************************************************************************
     * name: toString
     * Description: will display the information of the anima name, origin, danger
     * Parameters: none
     * Pre-Conditions: Player must choose number 6 in the main method to display 
     *                 the animals
     * Post-Conditions: The information will be displayed to the console
     ****************************************************************************/
    
    @Override
    public String toString() {
        return "Name: " + this.name + "\n" +
                "Origin: " + this.origin + "\n" +
                "Danger Rating: " + this.dangerRating + "\n";
    }
    
    abstract int FoodperWeek();//abstract method that will return the amount of food per week
}