/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/********************************************************************************
 * Program Filename: Net_Enem.java
 * Author: Luong, Micheal
 * Date: 11/13/16
 * Description: This is based/extended from the abstract class Obstacles and is 
 *              responsible for providing the basic template to build nets that 
 *              catches the animals.
 * Input: Keyboard, Obstacles.java, Interactive_Game.java
 * Output: Interactive_Game.java, Enemies.java
 ********************************************************************************/

package cryptozoo_micheal_luong;

/**
 *
 * @author micheal
 */

public class Net_Enem extends Obstacles{
    
    /*class construtor that uses the parameters from the super class Obstacles*/
    public Net_Enem(int obsY, int obsX, boolean triggered, String ObsAscii) {
        super(obsY, obsX, triggered, ObsAscii);
    }
}
