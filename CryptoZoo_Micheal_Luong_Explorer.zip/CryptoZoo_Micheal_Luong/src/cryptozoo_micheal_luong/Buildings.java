/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/********************************************************************************
 * Program Filename: Buildings.java
 * Author: Luong, Micheal
 * Date: 11/13/16
 * Description: This is based/extended from the abstract class Obstacles and is 
 *              responsible for providing the basic template for build buildings 
 *              to obstruct both the player and enemies movements.
 * Input: Keyboard, Obstacles.java, Interactive_Game.java
 * Output: Interactive_Game.java, Enemies.java
 ********************************************************************************/

package cryptozoo_micheal_luong;

/**
 *
 * @author micheal
 */
public class Buildings extends Obstacles{
        
    /*class construtor that uses the parameters from the super class Obstacles*/
    public Buildings(int obsY, int obsX, boolean Triggered, String ObsAscii) {
        super(obsY, obsX, Triggered, ObsAscii);
    }
}
