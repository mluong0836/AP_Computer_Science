/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/********************************************************************************
 * Program Filename: Obstacles.java
 * Author: Luong, Micheal
 * Date: 11/12/16
 * Description: This is an abstract class served as a template so the other 
 *              classes can use. The constructor holds 4 necessary variables.
 * Input: Keyboard
 * Output: Buildings.java, Enemies.java, Interactive_Game.java, Net_Enem.java
 ********************************************************************************/

package cryptozoo_micheal_luong;

/**
 *
 * @author micheal
 */


public abstract class Obstacles {
    int obsX;//for the object's x location
    int obsY;//for the objects y location
    boolean triggered;//boolean to determine if it should be in the interactive game
    String ObsAscii;//the ascii character to be represented

    /*class constructor that hold the y,x coordinates, the boolean to see if it has been caught, and the ascii character*/
    public Obstacles(int obsY, int obsX, boolean triggered, String ObsAscii) {
        this.obsX = obsX;
        this.obsY = obsY;
        this.triggered = triggered;
        this.ObsAscii = ObsAscii;
    }
}
