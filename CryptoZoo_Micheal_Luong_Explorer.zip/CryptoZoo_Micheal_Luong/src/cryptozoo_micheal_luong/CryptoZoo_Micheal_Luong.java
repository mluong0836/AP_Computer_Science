/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/********************************************************************************
 * Program Filename: CryptoZoo_Micheal_Luong.java
 * Author: Luong, Micheal
 * Date: 11/1/16
 * Description: This is the main class and is responsible for displaying the 
 *              animals, giving you choices to remove, see, add, or quit.
 * Input: Keyboard, Zoo.java
 * Output: Console, Zoo.Animal
 ********************************************************************************/

package cryptozoo_micheal_luong;
    import java.util.*;
/**
 *
 * @author micheal
 */
public class CryptoZoo_Micheal_Luong {
    public static Zoo menagerie = new Zoo();//new object zoo object menagerie 
    public static int answeradd;//will record player's 6 decisions
    public static String answername;//will record the answer to the name of the object to be set as a parameter
    public static String answerString;//records String responses
    public static int answerDangerRating;//records danger rating player wants to add
    public static String typeofFoodanswer;//records the String type of food to be set as the parameter
    public static int amounAnswer;//amount of food will be recorded here
    public static Scanner scan = new Scanner(System.in);//scanner to read player's input
    static Interactive_Game go;//new object Interactive_Game so we can access it's methods and variables as well
    public static Player player = new Player(5, 5, false, "♛", 1, 0);//creating a player object
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        boolean gameplay = true;//make gameloop start
        int response;
        menagerie.list();//starts adding the first 11 animals
        System.out.println("Here are the animals on display right now:\n\n");
        menagerie.ShowAll();//displays all the animal from the arraylist 
        
        while(gameplay) {
            intro();
            response = scan.nextInt();//records response
            if(response == 1) {//if response is 1 then you go to the add method
                System.out.println("What new type of animal do you want to add?");
                add();//goes to add method
            } else if(response == 2) {//if response is 2, then player wants to remove an animal from the Arraylist
                System.out.println("What animal do you want to remove?");
                scan.nextLine();
                answerString = scan.nextLine();
                menagerie.Remove(answerString);//goes to remove method
            } else if(response == 3) {//if response is 3, then player wants to mark an animal on tour
                System.out.println("What animal do you want to mark out on tour?");
                scan.nextLine();
                answerString = scan.nextLine();
                menagerie.MarkonTour(answerString);//goes to mark out ion tour method
            } else if(response == 4) {//if 4, then the animals with variable onTour set to true will be displayed
                System.out.println("Here are the animals on tour...");
                menagerie.ShowonTour();//method to display the animals on tour
            } else if(response == 5) {//if 5, then animals not on tour will only be displayed
                System.out.println("Here are the animals not on tour...");
                menagerie.ShowNotonTour();//method to to display animals not on tour
            } else if(response == 6) {//if 6, then player wants to showcase all animals
                menagerie.ShowAll();
            } else if(response == 7) {//player wants to play a catch game
                System.out.println("Let's begin...\n");
                System.out.println("_______________________________\n\n\n\n");
                go.create();
            } else if(response == 8) {//player wants to quit
                System.out.println("Thanks for playing.");
                gameplay = false;//ends the gameloop
            } else {
                System.out.println("I did not understand what you just said...");
            }
        }
    }
    
     /****************************************************************************
     * Method: The method name is intro
     * Description: Provides the introduction to the program/game
     * Parameters: none
     * Pre-Conditions: This is the first method that is called from the main class
     *                 when the player runs the game. 
     * Post-Conditions: Player will be given 7 choices
     ****************************************************************************/
    static void intro() {
        System.out.println("Welcome to the CryptoZoo.");
        System.out.println("How may we help you?\n");
        
        System.out.println("(1) Add an Animal to your catalog");
        System.out.println("(2) Remove an Animal from your catalog");
        System.out.println("(3) Mark an animal as out of tour");
        System.out.println("(4) Show all animals on tour");
        System.out.println("(5) Show all animals not on tour");
        System.out.println("(6) Show all animals.");
        System.out.println("(7) Play an interactive game");
        System.out.println("(8) Quit.");
    }
    
     /****************************************************************************
     * Method: The method name is add
     * Description: This method is for adding details to a new animal the player 
     *              wants to be included in the menagerie
     * Parameters: none
     * Pre-Conditions: Player has to choose number 1 as his/her choice
     * Post-Conditions: You will have the information to be sent over to 
     *                  the method addnewAnimals(type) with all the parameters.
     ****************************************************************************/
    public static void add() {
        System.out.println("(1) Mythical");
        System.out.println("(2) Paranormal");
        System.out.println("(3) LingerLing");
        System.out.println("(4) Fossil Relative");
        answeradd = scan.nextInt();
        System.out.println("What is the animal called?");
        scan.nextLine();//clears up the previous line so that the scanner will read the next new line
        answername = scan.nextLine();
        System.out.println("Where does this creature live?");
        answerString = scan.nextLine();
        System.out.println("What is it's danger rating from 0 to 10?");
        answerDangerRating = scan.nextInt();
        if(answeradd == 1) {//if the animal is a mythical animal, then is has two other series of necessary information to be filed out
            System.out.println("What type of food does it eat?");
            typeofFoodanswer = scan.next();
            System.out.println("What is the amount?");
            amounAnswer = scan.nextInt();
            /*calls the method to create a new Mythical animal object to the arraylist with these parameters*/
            menagerie.addnewAnimalsMythical(answername, answerString, answerDangerRating, typeofFoodanswer, amounAnswer);
        } else {
            /*Depending on the recorded choice, the player will be able to create a new object with that type*/
            if(answeradd == 2) {
                 /*calls the method to create a new Paranormal animal object to the arraylist with these parameters*/
                menagerie.addnewAnimalsParanormal(answername, answerString, answerDangerRating);
            } else if(answeradd == 3) {
                 /*calls the method to create a new LingerLing animal object to the arraylist with these parameters*/
                menagerie.addnewAnimalsLingerLing(answername, answerString, answerDangerRating);
            } else {
                 /*calls the method to create a new Fossil Relative animal object to the arraylist with these parameters*/
                menagerie.addnewAnimalsFossilRelative(answername, answerString, answerDangerRating);
            }
        }
    }
}