/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/********************************************************************************
 * Program Filename: Paranormal.java
 * Author: Luong, Micheal
 * Date: 11/7/16
 * Description: This class contains the class constructor to be used as the 
 *              template to build/create new Paranormal objects to be added in 
 *              the arraylist.
 * Input: Keyboard, Animal.java, ZooAnimal.java
 * Output: Zoo.java
 ********************************************************************************/

package cryptozoo_micheal_luong;

/**
 *
 * @author micheal
 */
public class Paranormal extends Animal {
    
    private String FoodType;
    private int Foodamt;
    
    /*Class constructor that holds parameters of the super class parameters and the ontour boolean, the y,x coordinates, and a 
      boolean to determine if the animal is caught in the interactive game yet.*/
    public Paranormal(String name, String origin, int dangerRate, boolean onTour, boolean alive, int enemRow, int enemCol) {
        super(name, origin, dangerRate, onTour, enemRow, enemCol, alive);
        FoodType = "meat";
        Foodamt = 5;
    }

    /****************************************************************************
     * Method: getFoodType()
     * Description: This is a getter method to get the foodtype this animal eats
     * Parameters: none
     * Pre-Conditions: When the player asks to display the aniamls
     * Post-Conditions: The information will be sent to the method that requires
     *                  it.
     ****************************************************************************/
    @Override
    public String getFoodType() {
        return FoodType;
    }
    
    /****************************************************************************
     * Method: The method name is setFoodType
     * Description: sets the food type of the animal
     * Parameters: String food
     * Pre-Conditions: Occurs when player decides to make a LingerLing object
     * Post-Conditions:This new foodtype will be set
     ****************************************************************************/
    @Override
    public void setFoodType(String FoodType) {
        this.FoodType = FoodType;
    }

     /****************************************************************************
     * Method: The method name is getFoodamt
     * Description: getter to return the food amount
     * Parameters: none
     * Pre-Conditions: Player decides to showcase animals
     * Post-Conditions: The food amount will be returned
     ****************************************************************************/
    @Override
    public int getFoodamt() {
        return Foodamt;
    }

    /****************************************************************************
     * Method: The method name is setFoodamt
     * Description: setter method to set the food amount
     * Parameters: int foodtype
     * Pre-Conditions: Player wants to create a new animal
     * Post-Conditions: Food amount will be set to that particular object
     ****************************************************************************/
    
    @Override
    public void setFoodamt(int Foodamt) {
        this.Foodamt = Foodamt;
    }
    
     /****************************************************************************
     * Method: The method name is FoodperWeek
     * Description: Provides the frequency of feeding the animal
     * Parameters: none
     * Pre-Conditions: Player wants to know how much to give 
     * Post-Conditions: The frequency is given.
     ****************************************************************************/
    
    @Override
    public int FoodperWeek() {
        return 1;
    }
}