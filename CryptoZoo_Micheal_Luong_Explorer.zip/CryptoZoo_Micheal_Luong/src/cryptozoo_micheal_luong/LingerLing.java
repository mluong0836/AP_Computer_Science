/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/********************************************************************************
 * Program Filename: LingerLing.java
 * Author: Luong, Micheal
 * Date: 11/4/16
 * Description: This is based/extended from the abstract class animal and will be
 *              responsible for providing the bsic template to build new LingerLing
 *              objects.
 * Input: Keyboard, Animal.java, ZooAnimal.java
 * Output: Zoo.java, FossilRelative.java
 ********************************************************************************/

package cryptozoo_micheal_luong;

/**
 *
 * @author micheal
 */
public class LingerLing extends Animal {
    
    /*Class constructor that holds parameters of the super class parameters and the ontour boolean, the y,x coordinates, and a 
      boolean to determine if the animal is caught in the interactive game yet.*/
    public LingerLing(String name, String origin, int dangerRate, boolean onTour, int enemRow, int enemCol, boolean alive) {
        super(name, origin, dangerRate, onTour, enemRow, enemCol, alive);
    }
    
    /****************************************************************************
     * Method: getFoodType()
     * Description: This is a getter method to get the foodtype this animal eats
     * Parameters: none
     * Pre-Conditions: When the player asks to display the aniamls
     * Post-Conditions: The information will be sent to the method that requires
     *                  it.
     ****************************************************************************/
    @Override
    public String getFoodType() {
        return "none";
    }
    
    /****************************************************************************
     * Method: The method name is setFoodType
     * Description: sets the food type of the animal
     * Parameters: String food
     * Pre-Conditions: Occurs when player decides to make a LingerLing object
     * Post-Conditions:This new foodtype will be set
     ****************************************************************************/
    @Override
    public void setFoodType(String food) {
        
    }
    
    /****************************************************************************
     * Method: The method name is getFoodamt
     * Description: getter to return the food amount
     * Parameters: none
     * Pre-Conditions: Player decides to showcase animals
     * Post-Conditions: The food amount will be returned
     ****************************************************************************/
    
    @Override
    public int getFoodamt() {
        return 0;
    }
    
    /****************************************************************************
     * Method: The method name is setFoodamt
     * Description: setter method to set the food amount
     * Parameters: int foodtype
     * Pre-Conditions: Player wants to create a new animal
     * Post-Conditions: Food amount will be set to that particular object
     ****************************************************************************/
    
    @Override 
    public void setFoodamt(int foodtype) {
        
    }
    
    /****************************************************************************
     * Method: The method name is FoodperWeek
     * Description: Provides the frequency of feeding the animal
     * Parameters: none
     * Pre-Conditions: Player wants to know how much to give 
     * Post-Conditions: The frequency is given.
     ****************************************************************************/
    @Override
    public int FoodperWeek() {
        return 1;
    }
    
}