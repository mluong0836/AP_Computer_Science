/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/********************************************************************************
 * Program Filename: Interactive_Game.java
 * Author: Luong, Micheal
 * Date: 11/12/16
 * Description: This is the class that will be responsible to create the obstacles,
 *              create the 2D map, print out the objects that will interact in the
 *              interactive Game mode, and be solely responsible for driving the
 *              CryptoZoo explorer session.
 * Input: Keyboard, Zoo.java, CryptoZoo_Micheal_Luong.java, Enemies.java,
 *        Player.java
 * Output: CryptoZoo_Micheal_Luong.java, Enemies.java, Player.java
 ********************************************************************************/

package cryptozoo_micheal_luong;
    import java.util.*;

/**
 *
 * @author micheal
 */

public class Interactive_Game extends CryptoZoo_Micheal_Luong {
    public static Random rand = new Random();//used to randomize locations on the 2d map
    static char interactive[][] = new char[20][20];//a 2d char map that serves as the game setting
    static ArrayList<Obstacles> objects = new ArrayList();//a Obstacles type ArrayList that holds all the obstacle objects 
    static Enemies enemy = new Enemies();//new enemy object
    
    
    
    public static void create() {
        
        /*Created 4 new game objects with randomized locations, initially set to true, and have ascii strings*/
        Net_Enem animalNet = new Net_Enem(rand.nextInt(10), rand.nextInt(10), true, "💣");//creates a new Net_Enem object
        objects.add(animalNet);//adds that object to the arraylist
        Net_Enem animalNet2 = new Net_Enem(rand.nextInt(10)+9, rand.nextInt(10) + 9, true, "💣");
        objects.add(animalNet2);
        Buildings build1 = new Buildings(rand.nextInt(10) + 9, rand.nextInt(10), true, "🏢");
        objects.add(build1);
        Buildings build2 = new Buildings(rand.nextInt(10), rand.nextInt(10) + 9, true, "🏢");
        objects.add(build2);
        
        boolean interactiveLoop = true;//starts the sub game loop
        
        while(interactiveLoop) {
            /*nested for looo to iterate through the 2d array and draw all the objects on to the map*/
            for(int i = 0; i < 20; i++) {
                for(int j = 0; j < 20; j++) {
                    if(i == player.getRowLoc() && j == player.getColLoc()) {//draws the player's ascii when the coordinates match
                        System.out.print(interactive[i][j] + player.getCharacter());
                        /*if the animal object's coordinates matches the one iterated through, then print out that character*/
                    } else if(i == Zoo.zooList.get(0).enemyrow && j == Zoo.zooList.get(0).enemcol && Zoo.zooList.get(0).alive) {
                        System.out.print(interactive[i][j] + "🐯");
                    } else if(i == Zoo.zooList.get(1).enemyrow && j == Zoo.zooList.get(1).enemcol && Zoo.zooList.get(1).alive) {
                        System.out.print(interactive[i][j] + "🐵");
                    } else if(i == Zoo.zooList.get(2).enemyrow && j == Zoo.zooList.get(2).enemcol && Zoo.zooList.get(2).alive) {
                        System.out.print(interactive[i][j] + "🐴");
                    } else if(i == Zoo.zooList.get(3).enemyrow && j == Zoo.zooList.get(3).enemcol && Zoo.zooList.get(3).alive) {
                        System.out.print(interactive[i][j] + "🐶");
                    } else if(i == Zoo.zooList.get(4).enemyrow && j == Zoo.zooList.get(4).enemcol && Zoo.zooList.get(4).alive) {
                        System.out.print(interactive[i][j] + "🐖");
                    } else if(i == Zoo.zooList.get(5).enemyrow && j == Zoo.zooList.get(5).enemcol && Zoo.zooList.get(5).alive) {
                        System.out.print(interactive[i][j] + "🐘");
                    } else if(i == Zoo.zooList.get(6).enemyrow && j == Zoo.zooList.get(6).enemcol && Zoo.zooList.get(6).alive) {
                        System.out.print(interactive[i][j] + "🐍");
                    } else if(i == Zoo.zooList.get(7).enemyrow && j == Zoo.zooList.get(7).enemcol && Zoo.zooList.get(7).alive) {
                        System.out.print(interactive[i][j] + "🐆");
                    } else if(i == Zoo.zooList.get(8).enemyrow && j == Zoo.zooList.get(8).enemcol && Zoo.zooList.get(8).alive) {
                        System.out.print(interactive[i][j] + "🐲");
                    } else if(i == Zoo.zooList.get(9).enemyrow && j == Zoo.zooList.get(9).enemcol && Zoo.zooList.get(9).alive) {
                        System.out.print(interactive[i][j] + "🐿");
                        /*if the game objects coordinates matches the ones being iterate through, then the external objects will be printed out*/
                    } else if(i == objects.get(0).obsY && j == objects.get(0).obsX && objects.get(0).triggered) {//prints out net game object
                        System.out.print(interactive[i][j] + objects.get(0).ObsAscii);
                    } else if(i == objects.get(1).obsY && j == objects.get(1).obsX && objects.get(1).triggered) {
                        System.out.print(interactive[i][j] + objects.get(1).ObsAscii);
                    } else if(i == objects.get(2).obsY && j == objects.get(2).obsX && objects.get(2).triggered) {//prints out the building objects
                        System.out.print(interactive[i][j] + objects.get(2).ObsAscii);
                    } else if(i == objects.get(3).obsY && j == objects.get(3).obsX && objects.get(3).triggered) {
                        System.out.print(interactive[i][j] + objects.get(3).ObsAscii);
                    } else {
                        System.out.print(interactive[i][j] + ".");
                    }
                }
                System.out.println("");
            }
            PlayerMovement();//controls the player's movements
                    
        }
    }
    
    public static void PlayerMovement() {
        Scanner scan = new Scanner(System.in);//reads player's input
        String response;//records player's input
        System.out.println("");
        player.ScoreBoard();//tells the score
        System.out.println("");
        System.out.println("Use (W) as UP\n"
                + "Use (A) as LEFT\n"
                + "Use (D) as RIGHT\n"
                + "use (S) as DOWN\n");
        response = scan.nextLine();//records response
        
        if(response.equalsIgnoreCase("W")) {//goes north
            player.setRowLoc(player.getRowLoc()-1);
            enemy.EnemyMovements(0);//passes a parameter of zero to the method EnemyMovements
        } else if(response.equalsIgnoreCase("A")) {//goes to the west
            player.setColLoc(player.getColLoc()-1);
            enemy.EnemyMovements(2);//passes a parameter of two to the method EnemyMovements
        } else if(response.equalsIgnoreCase("D")) {//goes to the east
            player.setColLoc(player.getColLoc()+1);
            enemy.EnemyMovements(3);//passes a parameter of three to the method EnemyMovements
        } else if(response.equalsIgnoreCase("S")) {//goes south
            player.setRowLoc(player.getRowLoc()+1);
            enemy.EnemyMovements(1);//passes a parameter of one to the method EnemyMovements
        }
        
        enemy.Collisions(player.getRowLoc(), player.getColLoc());//passes the player's coordinates as parameters to determine enemy movements
    }    
}
