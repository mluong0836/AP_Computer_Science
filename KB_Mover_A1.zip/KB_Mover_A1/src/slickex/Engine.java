package slickex;

import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.BasicGame;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.*;
import org.newdawn.slick.geom.Rectangle;
import java.util.List;
import java.util.ArrayList;

public class Engine extends BasicGame {
    
    public  static final int WIDTH = 640;
    public  static final int HEIGHT = 480;
    private int a = 10;
    
    private KeyboardMover dude;
    public static GameWorld gw;
    

    public Engine(String title) {
        super(title);
    }

    public static void main(String[] args) {
        start();
    }

    public static void start() {

        try {
            AppGameContainer game = new AppGameContainer(new Engine("Whoopty Do Excitement"));
            game.setMaximumLogicUpdateInterval(60);
            game.setDisplayMode(Engine.WIDTH, Engine.HEIGHT, false);
            game.setTargetFrameRate(60);
            game.setAlwaysRender(true);
            game.setVSync(true);
            game.setShowFPS(false);
            game.start();
        } catch (SlickException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void init(GameContainer gc) throws SlickException {

        gw = new GameWorld( new Rectangle(0, 0, Engine.WIDTH, Engine.HEIGHT));
        //keyboard controled player
        dude = new KeyboardMover( gw);
        //dude.setWASD(true);// to change to WASD control, or if adding another player
        
        //add all players to GameWorld gw
        gw.add(dude);
        
        //add all Objects to Game
        gw.add(new AutoMover(50,50,gw));
        gw.add(new AnchoredPiece(200,200,gw));
        
        
    }

    @Override
    public void render(GameContainer gc, Graphics g) throws SlickException {
        //this for loop draws all the GamePieces
        for(GamePiece go: gw.getAllPieces())
            go.getImage().draw(go.getX(), go.getY());
        g.setWorldClip(gw.getScreen());
        
        gw.getScore().render(g); //render the single scoreboard.  
    }

    @Override
    public void update(GameContainer gc, int delta) throws SlickException {
        
                //moves all the moving peices
                for(MovingPiece mover: gw.getMovers())
                {
                    mover.move();
                    mover.checkEdge();
                }
                
                //detects collisions on all objects.  
                gw.detectCollisions();
      
    }
}
