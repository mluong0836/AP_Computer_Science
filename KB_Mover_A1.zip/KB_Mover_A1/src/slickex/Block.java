/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package slickex;

import org.newdawn.slick.Image;
import org.newdawn.slick.geom.Rectangle;

/**
 *
 * @author rcasti3
 */
public class Block extends AnchoredPiece{
//example of a AnchoredPiece
//You can set the default Image, and over ride collide method
    
    public Block(GameWorld gw) {
        super(gw);
    }

    public Block(Image i, GameWorld gw) {
        super(i, gw);
    }

    public Block(int x, int y,GameWorld gw ) {
        super(x,y,gw);
    }

    public Block(Image i, int x, int y,GameWorld gw) {
        super(i, x,y,gw);
    }
    
}
