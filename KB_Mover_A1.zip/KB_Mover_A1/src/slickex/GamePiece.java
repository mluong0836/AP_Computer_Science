/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package slickex;

import java.util.List;
import org.newdawn.slick.Image;
import org.newdawn.slick.geom.Rectangle;

/**
 *
 * @author rcasti3
 */
public abstract class GamePiece {

    private Image img;
    private int x, y;
    protected GameWorld gw;

    public GamePiece(Image img, int x, int y, GameWorld gw) {
        this.img = img;
        this.x = x;
        this.y = y;
        this.gw = gw;
    }

    public GamePiece(Image img, GameWorld gw) {
        this(gw);
        this.img = img;
    }

    public GamePiece(int x, int y, GameWorld gw) {
        this.x = x;
        this.y = y;
        this.gw = gw;
        setImage("default.png");
    }

    public GamePiece(GameWorld gw) {
        this((int)(Math.random()* gw.getScreen().getWidth()),(int)(Math.random()* gw.getScreen().getHeight()),gw);
        setImage("default.png");
    }

    
    
    public Image getImage() {
        return img;
    }

    public void setImage(Image i) {
        img = i;
    }
    public void setImage(String file){
        try{
            setImage(new Image(file));
        }
        catch(Exception e){System.out.println("file not valid");}
    }
    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getWidth() {
        return img.getWidth();
    }

    public int getHeight() {
        return img.getHeight();
    }

    public Rectangle getRect() {
        return new Rectangle(x, y, getWidth(), getHeight());
    }

    public abstract void collide(List<GamePiece> objects);

}
