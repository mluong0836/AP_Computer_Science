/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package slickex;

import java.util.List;
import org.newdawn.slick.Image;
import org.newdawn.slick.geom.Rectangle;

/**
 *
 * @author rcasti3
 */
public class AutoMover extends MovingPiece {
//This class is for objects that move on their own
//override the move and checkEdge to change its behavior

    public AutoMover(GameWorld gw) {
        super(gw);
        setImage("mover.png");
    }

    public AutoMover(Image i, GameWorld gw) {
        super(i, gw);
    }

    public AutoMover(Image i, int x, int y, GameWorld gw) {
        super(i, x, y, gw);
    }

    public AutoMover(int x, int y, GameWorld gw) {
        super(x, y, gw);
        setImage("mover.png");
    }

    public void checkEdge() {
        //what to do when the thing hits the edge.  over ride to bounce or disappear.
        if (getX() < 0) {
            setX(0);
        }
        if (getY() < 0) {
            setY(0);
        }
        if (getY() >= gw.getScreen().getHeight() - getImage().getHeight()) {
            setY((int) (gw.getScreen().getHeight() - getImage().getHeight()));
        }

        if (getX() >= gw.getScreen().getWidth() - getImage().getWidth()) {
            setX((int) (gw.getScreen().getWidth() - getImage().getWidth()));

        }

    }

    public void move() {//moves slowly to the right. Over ride to change movement
        setX(getX() + 1);

    }

    public void collide(List<GamePiece> objects) {

    }
}
