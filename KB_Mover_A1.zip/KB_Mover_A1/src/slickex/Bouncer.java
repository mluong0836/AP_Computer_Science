/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package slickex;

import org.newdawn.slick.Image;
import org.newdawn.slick.geom.Rectangle;

/**
 *
 * @author rcasti3
 */
public class Bouncer extends AutoMover {
    //example of an AutoMover.  It moves right until it hits a wall
    // over ride edgeDetect, move, and collide

    private int speed = 5;

    public Bouncer(int x, int y, GameWorld gw) {
        super(x, y, gw);
        setImage("bouncer.png");
    }

    public Bouncer(GameWorld gw) {
        super(gw);
        setImage("bouncer.png");

    }

    public Bouncer(Image i, GameWorld gw) {
        super(i, gw);
    }

    public Bouncer(Image i, int x, int y, GameWorld gw) {
        super(i, x, y, gw);
    }

    @Override
    public void move() {
        setX(getX() + speed);
    }

    @Override
    public void checkEdge() {
        if (getX() < 0 || getX() >= gw.getScreen().getWidth() - getImage().getWidth()) {
            speed = -speed;
        }

    }

}
