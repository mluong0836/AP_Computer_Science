/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package slickex;

import java.util.ArrayList;
import java.util.List;
import org.newdawn.slick.geom.Rectangle;

/**
 *
 * @author rcasti3
 */
public class GameWorld {

    private List<GamePiece> pieces = new ArrayList<GamePiece>();
    private List<MovingPiece> movers = new ArrayList<MovingPiece>();
    private List<AnchoredPiece> nonMovers = new ArrayList<AnchoredPiece>();
    private Rectangle screen;
    private NumberDisplay score;

    public GameWorld(Rectangle screen) {
        this.screen = screen;
        score = new NumberDisplay("Score");
    }

    public Rectangle getScreen() {
        return screen;
    }

    public void add(GamePiece gp) {
        pieces.add(gp);
        if (gp instanceof MovingPiece) {
            movers.add((MovingPiece) gp);
        }
        if (gp instanceof AnchoredPiece) {
            nonMovers.add((AnchoredPiece) gp);
        }

    }

    public List<GamePiece> getAllPieces() {
        return pieces;
    }

    public List<MovingPiece> getMovers() {
        return movers;
    }

    public List<AnchoredPiece> getNonMovers() {
        return nonMovers;
    }

    public List<GamePiece> getIntersectingPieces(GamePiece thing) {
        ArrayList<GamePiece> objs = new ArrayList<GamePiece>();
        for (GamePiece gp : getAllPieces()) {
            if (gp != thing && thing.getRect().intersects(gp.getRect())) {
                objs.add(gp);
            }
        }
        return objs;
    }

    public boolean doTheyIntersect(GamePiece a, GamePiece b) {
        return a.getRect().intersects(b.getRect());
    }

    public void detectCollisions() {
        for (GamePiece gp : getAllPieces()) {
            gp.collide(getIntersectingPieces(gp));
        }

    }
    public NumberDisplay getScore(){
        return score;
    }
    public void increaseScore() {
        score.increase();
    }
}
