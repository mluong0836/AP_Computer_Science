/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package slickex;

import org.newdawn.slick.*;
import org.newdawn.slick.geom.Rectangle;

/**
 *
 * @author rcasti3
 */
public abstract class MovingPiece extends GamePiece {

    /**
     * and Object that moves, either by keyboard or automatically. it is
     * abtract, so it must be extended/sublassed
     */

    public MovingPiece(GameWorld gw) {
        super(gw);
        setImage("chicken.png");
    }

    public MovingPiece(Image i, GameWorld gw) {
        super(i, gw);
    }

    public MovingPiece(int x, int y, GameWorld gw) {
        super(x, y, gw);
        setImage("chicken.png");
    }

    public MovingPiece(Image i, int x, int y, GameWorld gw) {
        super(i, x, y, gw);
    }

    public abstract void move();

    public abstract void checkEdge();

}
