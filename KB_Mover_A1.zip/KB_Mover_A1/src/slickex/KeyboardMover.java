/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package slickex;

import java.util.List;
import org.newdawn.slick.Image;
import org.newdawn.slick.geom.Rectangle;
import org.newdawn.slick.Input;

/**
 *
 * @author rcasti3
 */
public class KeyboardMover extends MovingPiece {

    private Input input;
    private boolean wasd = false;

    public KeyboardMover(GameWorld gw) {
        super(gw);
        input = new Input(Engine.HEIGHT);
    }

    public KeyboardMover(Image i, GameWorld gw) {
        super(i, gw);
        input = new Input(Engine.HEIGHT);
    }

    public KeyboardMover(int x, int y, GameWorld gw) {
        super(x, y, gw);
        input = new Input(Engine.HEIGHT);

    }

    public KeyboardMover(Image i, int x, int y, GameWorld gw) {
        super(i, x, y, gw);
        input = new Input(Engine.HEIGHT);
    }
    public Input getInput()
    {
        return input;
    }
    public void upPress() {
        setY(getY() - 5);
    }

    public void downPress() {
        setY(getY() + 5);
    }

    public void rightPress() {
        setX(getX() + 5);
    }

    public void leftPress() {
        setX(getX() - 5);
    }

    public void setWASD(boolean wasd) {
        this.wasd = wasd;
    }
    
    public void move() {
        if (wasd) {//wasd control
            if (input.isKeyDown(Input.KEY_A)) {
                leftPress();
            }
            if (input.isKeyDown(Input.KEY_D)) {
                rightPress();
            }
            if (input.isKeyDown(Input.KEY_W)) {
                upPress();
            }
            if (input.isKeyDown(Input.KEY_S)) {
                downPress();
            }

        } else {  //arrow control
            if (input.isKeyDown(Input.KEY_LEFT)) {
                leftPress();
            }
            if (input.isKeyDown(Input.KEY_RIGHT)) {
                rightPress();
            }
            if (input.isKeyDown(Input.KEY_UP)) {
                upPress();
            }
            if (input.isKeyDown(Input.KEY_DOWN)) {
                downPress();
            }
        }
        //detect keyboard
    }

    public void checkEdge() {
        //what to do when the thing hits the edge.  over ride to bounce or disappear.
        if (getX() < 0) {
            setX(0);
        }
        if (getY() < 0) {
            setY(0);
        }
        if (getY() >= gw.getScreen().getHeight() - getImage().getHeight()) {
            setY((int) (gw.getScreen().getHeight() - getImage().getHeight()));
        }

        if (getX() >= gw.getScreen().getWidth() - getImage().getWidth()) {
            setX((int) (gw.getScreen().getWidth() - getImage().getWidth()));

        }

    }

    public void collide(List<GamePiece> objects) {
        if (objects.size() > 0) {
            gw.getScore().increase();
        }
    }
}
