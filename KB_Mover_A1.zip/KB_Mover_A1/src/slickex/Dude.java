/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package slickex;

import org.newdawn.slick.Image;
import org.newdawn.slick.geom.Rectangle;

/**
 *
 * @author rcasti3
 */
public class Dude extends KeyboardMover {
    /*example of a KeyboardMover.
     //over ride move, edgeDetect, collide 
     //over ride upPress, downPress, leftPress, and rightPress to change movement behavior
     //create your own methods, and use the getInput() method to detect other keys
     //Go here under "Field Summary" to see what keys can be detected:
     // http://slick.ninjacave.com/javadoc/org/newdawn/slick/Input.html
     // use code similar to : 
     //  if (input.isKeyDown(Input.KEY_A)) {//do something}
     */

    public Dude(Image i, GameWorld gw) {
        super(i, gw);
    }

    public Dude(Image i, int x, int y, GameWorld gw) {
        super(i, x, y, gw);
    }

    public Dude(int x, int y, GameWorld gw) {
        super(x, y, gw);
    }

    public Dude(GameWorld gw) {
        super(gw);
    }

}
