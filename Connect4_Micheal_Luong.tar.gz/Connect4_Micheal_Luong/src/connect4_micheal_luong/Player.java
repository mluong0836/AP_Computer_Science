/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connect4_micheal_luong;

import java.util.Scanner;

/**
 *
 * @author dong
 */
public class Player extends Grid{
    //Grid grid;
    private int pCol, pRow;
    private boolean pwin = false;

    public void pTurn() {
        Scanner scan = new Scanner(System.in);
        int response;
        boolean loop = true;
        while (loop) {
            System.out.println("Which column do you want to select?");
            response = scan.nextInt() - 1;//since player starts with 1 instead of zero
            if (BorderCheck(response)) {//checks border
                UpdateBoard(1, response);
                loop = false;//ends player's turn
            } else {
                System.out.println("That is an invalid location.");
            }
        }
    }

    public int getpCol() {
        return pCol;
    }

    public void setpCol(int pCol) {
        this.pCol = pCol;
    }

    public boolean isPwin() {
        return pwin;
    }

    public void setPwin(boolean pwin) {
        this.pwin = pwin;
    }

    public int getpRow() {
        return pRow;
    }

    public void setpRow(int pRow) {
        this.pRow = pRow;
    }
}
