/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connect4_micheal_luong;

    import java.util.Scanner;

/**
 *
 * @author dong
 */
public class Connect4_Micheal_Luong {

    /**
     * @param args the command line arguments
     */
    
    public static int counter = 0;
    public static int pwin, cwin;
    static Grid grid = new Grid();
    
    public static void main(String[] args) {
        // TODO code application logic here
        
        grid.init();
        boolean outerloop = true;
        Scanner scan = new Scanner(System.in);
        int answer;
        while (outerloop) {
            System.out.println("What would you like to do?");
            System.out.println("(1) Play a game of Connect 4.");
            System.out.println("(2) Play best 2 out of 3.");
            System.out.println("(3) Read the rule book.");
            System.out.println("(4) Quit");
            answer = scan.nextInt();
            
            if(answer == 1) {
                System.out.println("Let the games begin...");
                grid.GamePlay();
            } else if(answer == 2) {
                System.out.println("Let's start.");
                System.out.println("Whoever wins 2 games will be the winner.");
                boolean innerloop = true;
                while(innerloop) {
                    grid.GamePlay();
                    if(pwin == 2 || cwin == 2) {
                        innerloop = false;
                    }
                }
            } else if(answer == 3) {
                System.out.println("Player opens the rule book and begins reading...");
            } else if(answer == 4) {
                System.out.println("Thank you for playing!");
                outerloop = false;
            } else {
                System.out.println("I don't understand your response.");
            }
        }
    }
    
    private void Rules() {
        System.out.println("Hello");
    } 
}
