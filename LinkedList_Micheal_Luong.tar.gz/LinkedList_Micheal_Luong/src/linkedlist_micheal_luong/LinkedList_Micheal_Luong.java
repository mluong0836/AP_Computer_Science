/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linkedlist_micheal_luong;

    import java.util.Scanner;

/**
 *
 * @author dong
 */
public class LinkedList_Micheal_Luong {

    /**
     * @param args the command line arguments
     */
    
    static Scanner scan = new Scanner(System.in);
    
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("You are responsible for recording and reviewing all of the different \n"
                + "monsters, superheros, and wizards in the universe.");
        
        boolean gameplay = true;
        
        while(gameplay) {
            System.out.println("What would you like to do?");
        
            System.out.println("(1) Add a superhero, wizard, or monster.");
            System.out.println("(2) Remove the first superhero, wizard, or monster on your list.");
            System.out.println("(3) Remove the last superhero, wizard, or monster on your list.");
            System.out.println("(4) QUIT");
        
            int choice;
            choice = scan.nextInt();
        
            if(choice == 1) {
                System.out.println("You are opening your catalog...\n\n\n");
            } else if(choice == 2) {
                
            } else if(choice == 3) {
                
            } else if(choice == 4) {
                gameplay = false;
            } else {
                System.out.println("I don't understand what you want to do...");
            }
        }
        
        LinkedList L = new LinkedList();
        Character c = new Character("ANimal", "String", "D", 5);
        
    	L.add(c);
    	L.show();
    	L.add(c);
    	L.show();
    	L.add(c);
    	L.show();
    	L.deleteNodeWithData(2);
    	L.show();
    	L.deleteNodeAtIndex(3);
    	L.show();
    	L.deleteNodeAtIndex(1);
    	L.show();
    }
    
}
