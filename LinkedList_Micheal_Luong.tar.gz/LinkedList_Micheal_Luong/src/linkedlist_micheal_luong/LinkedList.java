/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linkedlist_micheal_luong;

/**
 *
 * @author dong
 */
public class LinkedList {
    public Node head;
    public int listCount;

    Character Superman = new Character("Superman", "Human", "Laser", 200);
    public LinkedList() {
        this.head = new Node(Superman);
        this.listCount = 0;
    }
    
    public void show() {
        Node current = head;
        while(current.next != null) {
            System.out.print(current.data + " -> ");
            current = current.next;
        }
        
        System.out.println(current.data);
    }
    
    public boolean add(Character d){
    	Node end = new Node(d);
    	Node current = head;

    	while(current.next != null){
    		current = current.next;
    	}
    	current.next = end;
    	listCount++;
        System.out.println(d+" appended to tail!");
        return true;
    }

    public boolean add(Character d,int index){
    	Node end = new Node(d);
    	Node current = head;
    	int jump;

    	if(index>listCount || index<1){
    		System.out.println("Add Failed: index out of bounds of size of linked list!!");
    		return false;
    	}
    	else{
    		jump = 0;
    		while(jump<index-1){
    			current = current.next;
    			jump++;
    		}
    		end.next = current.next;
    		current.next = end;
    		listCount++;
    		System.out.println("Success! "+d+" added at index "+index);
            return true;
    	}
    }

    public boolean deleteNodeWithData(int d){
    	Node current = head;
        while(current.next!=null){
            if(current.next.data==d){
                current.next = current.next.next;
                listCount--;
                System.out.println("Success! Node with data "+d+" deleted.");
                return true;
            }
            current = current.next;
        }
        System.out.println("Delete Failed: No node found with given data!");
        return false;
    }

    public boolean deleteNodeAtIndex(int index){
    	Node current = head;
    	int jump;
    	if(index>listCount || index<1){
    		System.out.println("Delete Failed: index out of bounds of size of linked list!!");
    		return false;
    	}    	
    	else{
    		jump=0;
    		while(jump<index-1){
    			current = current.next;
    			jump++;
    		}
    		current.next = current.next.next;
    		System.out.println("Success! Node at index "+index+" deleted.");
    		listCount--;
    		return true;
    	}
    }
}

