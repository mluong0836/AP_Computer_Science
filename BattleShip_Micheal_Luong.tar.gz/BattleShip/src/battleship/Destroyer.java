/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package battleship;

/**
 *
 * @author dong
 */
public class Destroyer extends Ship{

    private int size;
    private int DestroyerShipHits = 0;
    
    public Destroyer(String Name, boolean Alive, int xLoc, int yLoc, int Rotation, int Size) {
        super(Name, Alive, xLoc, yLoc, Rotation, Size);
    }

    @Override
    public int getShipHits() {
        return this.DestroyerShipHits;
    }
    
    @Override
    public int setShipHits(int hits) {
        return this.DestroyerShipHits = hits;
    }
    
    public int getSize() {
        return this.size;
    }

    public void setSize(int size) {
        this.size = size;
    }
}
