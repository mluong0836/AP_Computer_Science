/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package battleship;

    import java.util.ArrayList;

/**
 *
 * @author dong
 */

public class Grid extends Player{

    public static ArrayList<Ship> shipsLeft = new ArrayList();
    public static int[][] grid = new int[10][10];
    public boolean match = false;
    
    public void CreateShips(int type, int x, int y, int rotation) {
        if (type == 1) {//Carrier declared, initialized, and added to arraylist
            AircraftCarrier ship1 = new AircraftCarrier("Aircraft Carrier", true, x, y, rotation, 5);
            shipsLeft.add(ship1);
            System.out.print("Your AirCraft Carrier has been placed ");
        } else if (type == 2) {//Battleship declared, initialized, and added to arraylist
            BattleShip ship2 = new BattleShip("Battle Ship", true, x, y, rotation, 4);
            shipsLeft.add(ship2);
            System.out.print("Your Battle Ship has been placed ");
        } else if (type == 3) {//Cruiser declared, initialized, and added to arraylist
            Cruiser ship3 = new Cruiser("Cruiser", true, x, y, rotation, 3);
            shipsLeft.add(ship3);
            System.out.print("Your Cruiser has been placed ");
        } else if (type == 4) {//Destroyer declared, initialized, and added to arraylist
            Destroyer ship4 = new Destroyer("Destroyer", true, x, y, rotation, 2);
            shipsLeft.add(ship4);
            System.out.print("Your Destroyer has been placed ");
        } else if (type == 5) {//Submarine declared, initialized, and added to arraylist
            Submarine ship5 = new Submarine("Submarine", true, x, y, rotation, 3);
            shipsLeft.add(ship5);
            System.out.print("Your Submarine has been placed ");
        }
        System.out.println("at\nRow: " + (x+1) + " \nColumn " + (y+1)  + ".");
        AddToGrid(type, rotation, x, y, shipsLeft.get(shipsLeft.size()-1).size);
    }

    public void AddToGrid(int type, int Rotation, int row, int col, int size) {
        int counter = 0;
        boolean go = true;
        while (go) {
            if (Rotation == 1) {//forward
                if(counter <= size - 1) {
                    grid[row - counter][col] = type;
                } else {
                    go = false;
                }
            } else if (Rotation == 2) {//Down
                if(counter <= size - 1) {
                    grid[row + counter][col] = type;
                } else {
                    go = false;
                }
            } else if (Rotation <= 3) {//Left
                if(counter <= size - 1) {
                    grid[row][col - counter] = type;
                } else {
                    go = false;
                }
            } else if (Rotation <= 4) {//Right
                if(counter <= size - 1) {
                    grid[row][col + counter] = type;
                } else {
                    go = false;
                }
            }
            counter++;
        }
    }
    
    public void printAiHitMissMap() throws InterruptedException {//prints out the AI display map so player knows where they've guessed and hit

        for(int i = 0; i < 10; i++) {
            for(int j = 0; j < 10; j++) {
                if(Computer.getAIDisplay()[i][j] == 1) {//hit
                    //System.out.print(Color.RED + Computer.getAIGrid()[i][j] + "*" + Color.RESET);
                    System.out.print(Color.RED + " * " + Color.RESET);
                } else if(Computer.getAIDisplay()[i][j] == 2) {//miss
                    System.out.print(Color.WHITE +" * " + Color.RESET);
                } else {//neither because you haven't guessed at that location yet
                    System.out.print(Color.PURPLE + " 0 " + Color.RESET);
                }
            }
            System.out.println("");
        }
        
        for(int skip = 0; skip < 3; skip++) {
            System.out.println("");   
        }
        
        Thread.sleep(2000);
    }
    
    public void printPlayerMap() throws InterruptedException {//prints player's map with the player's ships, hits, and misses that th comp inflicts upon
        for(int i = 0; i < 10; i++) {
            for(int j = 0; j < 10; j++) {
                if(grid[i][j] == 1) {//remaining untouched aircraft ship
                    System.out.print(Color.PURPLE + " ❏ " + Color.RESET);
                } else if(grid[i][j] == 2) {//remaining untouched battle ship 
                    System.out.print(Color.GREEN + " ❏ " + Color.RESET);
                } else if(grid[i][j] == 3) {//remaining untouched cruiser 
                    System.out.print(Color.CYAN + " ❏ " + Color.RESET);
                } else if(grid[i][j] == 4) {//remaining untouched destroyer ship
                    System.out.print(Color.BLUE + " ❏ " + Color.RESET);
                } else if(grid[i][j] == 5) {//remaining untouched submarine ship
                    System.out.print(Color.GREEN + " ❏ " + Color.RESET);
                } else if(grid[i][j] == 6) {//hits that AI guessed correctly
                    System.out.print(Color.RED + " 🔥 " + Color.RESET);
                } else if(grid[i][j] == 7) {//misses that AI guessed incorrectly
                    System.out.print(Color.WHITE + " * " + Color.RESET);
                } else {//untouched by AI guesses
                    System.out.print(Color.YELLOW + " 0 " + Color.RESET);
                }
            }
            System.out.println("");
        }
        
        for(int skip = 0; skip < 3; skip++) {
            System.out.println("");
        }
        
        Thread.sleep(2000);
    }
    
    public boolean CheckBoundaries(int row, int col, int Rotate, int type) {
        
        int size = 0;
        
        if(type == 1) {
            size = 5;
        } else if(type == 2) {
            size = 4;
        } else if(type == 3) {
            size = 3;
        } else if(type == 4) {
            size = 2;
        } else {
            size = 3;
        }
        
        boolean valid = true;
        if(Rotate == 1) {
            if(row - size < 0) {
                valid = false;
            }
        } else if (Rotate == 2) {
            if(row + size > 9) {
                valid = false;
            }
        } else if (Rotate == 3) {
            if(col- size < 0) {
                valid = false;
            }
        } else if(Rotate == 4) {
            if(col+size > 9) {
                valid = false;
            }
        } 
        System.out.println(valid);
        return valid;
    }
    
    void Init() {
        for(int i = 0; i < 10; i++) {
            for(int j = 0;  j < 10; j++) {
                if(grid[i][j] != 1 && grid[i][j] != 2 && grid[i][j] != 3 && grid[i][j] != 4 && grid[i][j] != 5) {
                    grid[i][j] = 0;
                }
            }
        }
    }
    
    public boolean CheckInputMatching(int row, int col, int Rotate, int type) {
        
        int counter = 0;
        int size = 0;
        boolean go = true;
        boolean valid = false;
        
        if(type == 1) {
            size = 5;
        } else if(type == 2) {
            size = 4;
        } else if(type == 3) {
            size = 3;
        } else if(type == 4) {
            size = 2;
        } else {
            size = 3;
        }
        
        while (go) {
            if (Rotate == 1) {//forward
                if(counter < size && grid[row - counter][col] == 0) {
                    go = true;
                } else {
                    if(grid[row - counter][col] == 0) {
                        valid = true;
                    } else {
                        valid = false;
                        match = true;
                    }
                    go = false;
                }
            } else if (Rotate == 2) {//Down
                if(counter < size && grid[row + counter][col] == 0) {
                    go = true;
                } else {
                    if(grid[row + counter][col] == 0) {
                        valid = true;
                    } else {
                        valid = false;
                        match = true;
                    }
                    go = false;
                }
            } else if (Rotate == 3) {//Left
                if(counter < size && grid[row][col - counter] == 0) {
                    go = true;
                } else {
                    if(grid[row][col - counter] == 0) {
                        valid = true;
                    } else {
                        valid = false;
                        match = true;
                    }
                    go = false;
                }
            } else if (Rotate == 4) {//Right
                if(counter < size && grid[row][col + counter] == 0) {
                    go = true;
                } else {
                    if(grid[row][col + counter] == 0) {
                        valid = true;
                    } else {
                        valid = false;
                        match = true;
                    }
                    go = false;
                }
            }
            counter++;
        }
        System.out.println(valid);
        return valid;
    }
}
