/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package battleship;

import java.util.Timer;
import java.util.TimerTask;

/**
 *
 * @author dong
 */
public class TimerForMusic {

    private int secondsPassed = 0;
    Timer timer = new Timer();
    private boolean rerun;

    public TimerForMusic(boolean reloop) {
        this.rerun = reloop;
    }
    
    public void Init() {
        TimerTask task = new TimerTask() {
            public void run() {
                setSecondsPassed(getSecondsPassed() + 1);
                Check(getSecondsPassed());
            }
        };
        timer.scheduleAtFixedRate(task, 1000, 1000);
    }
    
    public void Check(int seconds) {
        if(seconds >= 60) {
            this.rerun = true;
        }
    }

    public boolean isRerun() {
        return rerun;
    }

    public int getSecondsPassed() {
        return secondsPassed;
    }

    public void setSecondsPassed(int secondsPassed) {
        this.secondsPassed = secondsPassed;
    }

    public void setRerun(boolean rerun) {
        this.rerun = rerun;
    }
}
