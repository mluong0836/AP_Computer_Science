/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package battleship;

import java.io.IOException;
    import java.util.ArrayList;
    import java.util.Random;

/**
 *
 * @author dong
 */
public class Computer extends Grid {
    
    private Ansi_Art text = new Ansi_Art();
    private static ArrayList<Ship> CompShips = new ArrayList();
    private boolean gotHitLastTurn = false, first = true;
    private static final int[][] AIGrid = new int[10][10];
    private static int[][] AIDisplay = new int[10][10];//this will be the map that shows hit/misses 0 = haven't touched, 1 = hit, 2 = miss
    static Random rand = new Random();
    Player player = new Player();
    private int tempType = 0;
    private ArrayList <Integer> smartRotations = new ArrayList();
    
    private ArrayList<StoredCoordinates> SmartAi = new ArrayList();
    
    Sound sound = new Sound();

    public Computer() {
        
    }
    
    public void CompInit() {//initializes ai grid and adds ships to arraylist
        boolean end = false;
        boolean endInnerLoop = false;
        int totalShips = 0;
        int counter = 0;
        int[] shipSizes = {5,4,3,2,3};
        int row = 0, col = 0, rotation = 1;
        while(!end) {
            if(totalShips <= 4) {
                do {
                    row = rand.nextInt(10);
                    col = rand.nextInt(10);
                    rotation = rand.nextInt(4) + 1;
                    if(Boundaries(row, col, rotation, shipSizes[counter]) == false) {
                        endInnerLoop = false;//continues to loop
                    } else {
                        if(CheckInitMatches(row, col, rotation, shipSizes[counter]) == false) {
                            endInnerLoop  = false;
                        } else {
                            endInnerLoop = true;//ends loop both conditions are met
                        } 
                    }
                } while(!endInnerLoop);
                totalShips++;//add here first so you don't need to worry about adding errors later
                addCompShips(row, col, rotation, shipSizes[counter], totalShips);
                counter++;
            } else {
                end = true;
            }
            
        }
        
    }
    
    private boolean CheckInitMatches(int row, int col, int rotation, int size) {
        
        boolean valid = true;
        boolean loop = true;
        int counter = 0;
        while(loop) {
            if(rotation == 1) {//pos = up
                if(counter < size && AIGrid[row - counter][col] == 0) {//continue loop
                    loop = true;
                } else {
                    if(AIGrid[row - counter][col] == 0) {
                        valid = true;
                    } else {
                        valid = false;
                    }
                    loop = false;    
                }
            } else if(rotation == 2) {
                if(counter < size && AIGrid[row + counter][col] == 0) {
                    loop = true;
                } else {
                    if((AIGrid[row + counter][col] == 0)) {
                        valid = true;
                    } else {
                        valid = false;
                    }
                    loop = false;
                }
            } else if(rotation == 3) {
                if(counter < size && AIGrid[row][col - counter] == 0) {
                    loop = true;
                } else {
                    if(AIGrid[row][col - counter] == 0) {
                        valid = true;
                    } else {
                        valid = false;
                    }
                    loop = false;
                }
            } else if(rotation == 4) {
                if( counter < size && AIGrid[row][col + counter] == 0 ) {
                    loop = true;
                } else {
                    if(AIGrid[row][col + counter] == 0) {
                        valid = true;
                    } else {
                        valid = false;
                    }
                    loop = false;
                }
            }
            counter++;
        }
        return valid;
    }
    
    private boolean Boundaries(int row, int col, int rotation, int size) {
        
        boolean valid = true;
        
        if(rotation == 1) {
            if(row - size < 0) {
                valid = false;
            }
        } else if (rotation == 2) {
            if(row + size > 9) {
                valid = false;
            }
        } else if (rotation == 3) {
            if(col- size < 0) {
                valid = false;
            }
        } else if(rotation == 4) {
            if(col+size > 9) {
                valid = false;
            }
        } 
        System.out.println(valid);
        return valid;
    }
    
    private void addCompShips(int row, int col, int rotation, int size, int type) {
        int counter = 0;
        boolean loop = true;
        while(loop) {
            if (rotation == 1) {//forward
                if(counter <= size - 1) {
                    AIGrid[row - counter][col] = type;
                } else {
                    loop = false;
                }
            } else if (rotation == 2) {//Down
                if(counter <= size - 1) {
                    AIGrid[row + counter][col] = type;
                } else {
                    loop = false;
                }
            } else if (rotation <= 3) {//Left
                if(counter <= size - 1) {
                    AIGrid[row][col - counter] = type;
                } else {
                    loop = false;
                }
            } else if (rotation <= 4) {//Right
                if(counter <= size - 1) {
                    AIGrid[row][col + counter] = type;
                } else {
                    loop = false;
                }
            }
            counter++;
        }
        
        if(type == 1) {
            AircraftCarrier ship1 = new AircraftCarrier("Aircraft Carrier", true, row, col, rotation, 5);
            CompShips.add(ship1);
        } else if(type == 2) {
            BattleShip ship2 = new BattleShip("Battle Ship", true, row, col, rotation, 4);
            CompShips.add(ship2);
        } else if(type == 3) {
            Cruiser ship3 = new Cruiser("Cruiser", true, row, col, rotation, 3);
            CompShips.add(ship3);
        } else if(type == 4) {
            Destroyer ship4 = new Destroyer("Destroyer", true, row, col, rotation, 2);
            CompShips.add(ship4);
        } else if(type == 5) {
            Submarine ship5 = new Submarine("Submarine", true, row, col, rotation, 3);
            CompShips.add(ship5);
        }
    }
    
    public void AiTurn() throws IOException {
        int row = 0;
        int col = 0;
        
        /*this makes the AI smarter, since it would guess near the ship if there was a ship there*/
        if(!gotHitLastTurn) {
            do {
                row = rand.nextInt(9);
                col = rand.nextInt(9);
            } while(!CheckMatch(row, col));
            Sound.Init(1);//fired sound
            sound.Start();
            CheckHit(row, col);//checks the coordinates
        } else {//already had a hit
            SmartGuess();//will check the hits in smart AI mode
        }
    }
    
    private boolean CheckMatch(int row, int col) {
        boolean valid = false;
        if(grid[row][col] == 6) {//already hit the object
            valid = false;
        } else if(grid[row][col] == 7) {//already tried that place, but was a miss
            valid = false;
        } else {
            valid = true;//this represents a new coordinate
        }
        return valid;
    }
    
    private void CheckHit(int row, int col) throws IOException {
        
        if(grid[row][col] == 0) {//missed
            grid[row][col] = 7;
            /*prints out Computer Missed*/
            text.Character(2);
            text.Miss();
            gotHitLastTurn = false;
        } else if(grid[row][col] == 1) {//hit aircraft carrier 
            grid[row][col] = 6;
            shipsLeft.get(0).setShipHits(shipsLeft.get(0).getShipHits() + 1);//adds to the total hits
            gotHitLastTurn = true;
            tempType = 1;
            text.Character(2);
            text.Hit();
            text.ShipName(1);
            ShipDestroyed(shipsLeft.get(0));
        } else if(grid[row][col] == 2) {//hit battle ship
            grid[row][col] = 6;
            shipsLeft.get(1).setShipHits(shipsLeft.get(1).getShipHits() + 1);
            gotHitLastTurn = true;
            tempType = 2;
            text.Character(2);
            text.Hit();
            text.ShipName(2);
            ShipDestroyed(shipsLeft.get(1));
        } else if(grid[row][col] == 3) {//hit cruiser
            grid[row][col] = 6;
            shipsLeft.get(2).setShipHits(shipsLeft.get(2).getShipHits() + 1);
            gotHitLastTurn = true;
            tempType = 3;
            text.Character(2);
            text.Hit();
            text.ShipName(3);
            ShipDestroyed(shipsLeft.get(2));
        } else if(grid[row][col] == 4) {//hit destroyer
            grid[row][col] = 6;
            shipsLeft.get(3).setShipHits(shipsLeft.get(3).getShipHits() + 1);
            gotHitLastTurn = true;
            tempType = 4;
            text.Character(2);
            text.Hit();
            text.ShipName(4);
            ShipDestroyed(shipsLeft.get(3));
        } else if(grid[row][col] == 5) {//hit a submarine
            grid[row][col] = 6;
            shipsLeft.get(4).setShipHits(shipsLeft.get(4).getShipHits() + 1);
            gotHitLastTurn = true;
            tempType = 5;
            text.Character(2);
            text.Hit();
            text.ShipName(5);
            ShipDestroyed(shipsLeft.get(4));
        }
        
        if(Win(shipsLeft)) {
            Sound.Init(4);//fired sound
            sound.Start();
            System.out.println("OH NO. The AI destroyed your last ship...");
            System.out.println("YOU LOSE.\n");
            System.out.println("Thank you for playing.");
            GamePlay gameplay = new GamePlay();
//            gameplay.setGameplay(false);
            text.Lose();
            gameplay.loops = false;
        }        
    }
    
    private void ShipDestroyed(Ship ship) throws IOException {
        if(ship.getShipHits() >= ship.size) {
            Sound.Init(2);//destroyed sound
            sound.Start();
            System.out.println("The AI destroyed your " + ship.name + ".");
            text.Character(2);
            text.Destroyed();
            text.ShipName(tempType);//temptype was just recorded after the hit
            ship.setIsAlive(false);
            //tempCounter = 0;//this is right here
            gotHitLastTurn = false;
        }
    }
    
    private boolean Win(ArrayList<Ship> ship) {
        boolean Compwin = false;
        int shipsDestroyed = 0;
        for(int i = 0; i < ship.size(); i++) {
            if(ship.get(i).isAlive() == false) {
                shipsDestroyed++;
            }
        }
        if(shipsDestroyed == 5) {
            Compwin = true;
        } else {
            Compwin = false;
        }
        
        return Compwin;
    }
    
    private void SmartGuess() throws IOException {
        boolean loop = true;
        int pos;
        int counter = 0; 
        System.out.println("first time");
        
        
        if(first) {
            for(int i = 0; i < 4; i++) {
                pos = rand.nextInt(4) + 1;
                smartRotations.add(pos);
                first = false;
            }
        }
        
        /*************************************/
        int randomizer;
        if(counter == 0) {
            for(int i = 0; i < 10; i++) {
                for (int j = 0; j < 10; j++) {
                    if(grid[i][j] == tempType) {
                        SmartAi.add(new StoredCoordinates(i, j));
                    }
                }
            }
        }
        while(loop) {
            randomizer = rand.nextInt(SmartAi.size());
            CheckHit(SmartAi.get(randomizer).getX(), SmartAi.get(randomizer).getY());
            Sound.Init(1);//fired sound
            sound.Start();
            SmartAi.remove(randomizer);
            counter++;
            loop = false;
            if(SmartAi.isEmpty()) {
                counter = 0;
                loop = false;
            }
        }
        /************************************/
        
        /*while(loop) {//so you don't have to worry about going back to the comp turn until ship is destroyed
            System.out.println("Counter : " + counter);
            if(smartRotations.get(counter) == 1) {//up
                row--;
                System.out.println(row);
                if(SmartBoundary(row, col)) {//hit
                    System.out.println("passed");
                    CheckHit(row, col);
                    loop = false;
                } else {
                    row++;//back at same position
                    counter++;
                    System.out.println("before error");
                }
            } else if(smartRotations.get(counter) == 2) {//down
                row++;
                if(SmartBoundary(row, col)) {//hit
                    CheckHit(row, col);
                    loop = false;
                } else {
                    row--;
                    counter++;
                }
            } else if(smartRotations.get(counter) == 3) {//left
                col--;
                if(SmartBoundary(row, col)) {//hit
                    CheckHit(row, col);
                    loop = false;
                } else {
                    col++;
                    counter++;
                }
            } else {//right
                col++;
                if(SmartBoundary(row, col)) {//hit
                    CheckHit(row, col);
                    loop = false;
                } else {
                    col--;
                    counter++;
                }
            }
            
            if(counter == 4) {
                loop = false;
                tempCounter = 0;
                counter = 0;
            }
            
            if(tempCounter == 4) {
                for(int i = 0; i < 4; i++) {
                    pos = rand.nextInt(4) + 1;
                    smartRotations.add(pos);
                }
            }
            
            tempCounter++;
        }*/
    }
    
//    private boolean SmartBoundary(int row, int col) {
//        
//        boolean valid;
//        
//        if(row < 0 || row > 9 || col < 0 || col > 9) {//out of bounds
//                valid = false;
//        } else {//this is within bounds
//            if(grid[row][col] != tempType) {//miss
//                valid = false;
//            } else {
//                valid = true;
//            }
//        }
//        
//        return valid;
//    }
    
    
    
    public static int[][] getAIGrid() {
        return AIGrid;
    }

    public static void setAIGrid(int row, int col, int value) {
        Computer.AIGrid[row][col] = value;
    }

    public static int[][] getAIDisplay() {
        return AIDisplay;
    }

    public static void setAIDisplay(int row, int col, int value) {
        Computer.AIDisplay[row][col] = value;
    } 

    public static ArrayList<Ship> getCompShips() {
        return CompShips;
    }

    public static void setCompShips(ArrayList<Ship> CompShips) {
        Computer.CompShips = CompShips;
    }
}