/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package battleship;

/**
 *
 * @author dong
 */
public abstract class Ship implements StoredHits{
    String name;
    private boolean isAlive;
    int x;
    int y;
    int rotation;
    int size;
    
    public Ship(String Name, boolean Alive, int xLoc, int yLoc, int Rotation, int Size) {
        this.name = Name;
        this.isAlive = Alive;
        this.x = xLoc;
        this.y = yLoc;
        this.rotation = Rotation;
        this.size = Size;
    }

    public boolean isAlive() {
        return isAlive;
    }

    public void setIsAlive(boolean isAlive) {
        this.isAlive = isAlive;
    }
}