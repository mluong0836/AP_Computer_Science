/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package battleship;

import java.io.IOException;
    import java.util.ArrayList;
    import java.util.Scanner;

/**
 *
 * @author dong
 */

public class Player {
    static Scanner read = new Scanner(System.in);
    Sound sound = new Sound();
    //Grid grid = new Grid();
    //public int[][] PGrid = new int[10][10];
    //public static int[][] AIGrid;
    //public static int[][] AIDisplay = new int[10][10];//this will be the map that shows hit/misses 1 = hit, 2 = false
    private Ansi_Art text = new Ansi_Art();
//    public Player(int[][] Player) {
//        this.PGrid = Player;
//    }
        
    public void Pturn() throws IOException {
        System.out.println("What coordinate do you want our crew to fire at...");
        System.out.print("Row: ");
        int responsex;
        responsex = read.nextInt() - 1;
        System.out.print("Column: ");
        int responsey;
        responsey = read.nextInt() - 1;
        if(CheckMatch(responsex, responsey)) {//if valid then continue on to miss/hit
            Sound.Init(1);//fired sound
            sound.Start();
            CheckHit(responsex, responsey);
        }
    }
    
    private void CheckHit(int row, int col) throws IOException {
        if(Computer.getAIGrid()[row][col] != 0) {//hit
            System.out.println("HIT!");
            if(Computer.getAIGrid()[row][col] == 1) {
                //System.out.println("You fired at the Enemy's Aircraft Carrier!");
                Computer.setAIDisplay(row, col, 1);
                Computer.getCompShips().get(0).setShipHits(Computer.getCompShips().get(0).getShipHits() + 1);//adds to the total hits
                text.Character(1);
                text.Hit();
                text.ShipName(1);
                ShipDestroyed(Computer.getCompShips().get(0), 1);
                //AIDisplay[row][col] = 1;//displays a hit symbol
            } else if(Computer.getAIGrid()[row][col] == 2) {
                //System.out.println("You fired at the Enemy's Battle Ship!");
                Computer.setAIDisplay(row, col, 1);
                Computer.getCompShips().get(1).setShipHits(Computer.getCompShips().get(1).getShipHits() + 1);
                text.Character(1);
                text.Hit();
                text.ShipName(2);
                ShipDestroyed(Computer.getCompShips().get(1), 2);
                //AIDisplay[row][col] = 1;//displays a hit symbol
            } else if(Computer.getAIGrid()[row][col] == 3) {
                //System.out.println("You fired at the Enemy's Cruiser!");
                Computer.setAIDisplay(row, col, 1);
                Computer.getCompShips().get(2).setShipHits(Computer.getCompShips().get(2).getShipHits() + 1);
                text.Character(1);
                text.Hit();
                text.ShipName(3);
                ShipDestroyed(Computer.getCompShips().get(2), 3);
                //AIDisplay[row][col] = 1;//displays a hit symbol
            } else if(Computer.getAIGrid()[row][col] == 4) {
                //System.out.println("You fired at the Enemy's Destroyer!");
                Computer.setAIDisplay(row, col, 1);
                Computer.getCompShips().get(3).setShipHits(Computer.getCompShips().get(3).getShipHits() + 1);
                text.Character(1);
                text.Hit();
                text.ShipName(4);
                ShipDestroyed(Computer.getCompShips().get(3), 4);
                //AIDisplay[row][col] = 1;//displays a hit symbol
            } else if(Computer.getAIGrid()[row][col] == 5) {
                //System.out.println("You fired at the Enemy's Submarine!");
                Computer.setAIDisplay(row, col, 1);
                Computer.getCompShips().get(4).setShipHits(Computer.getCompShips().get(4).getShipHits() + 1);
                text.Character(1);
                text.Hit();
                text.ShipName(5);
                ShipDestroyed(Computer.getCompShips().get(4), 5);
                //AIDisplay[row][col] = 1;//displays a hit symbol
            }
        } else {//miss
            //System.out.println("MISS!");
            //System.out.print((row) + ", " + (col) + ".");
           // System.out.println("was a miss.");
           text.Character(1);
           text.Miss();
            Computer.setAIDisplay(row, col, 2);
            //AIDisplay[row][col] = 2;//displays a hit symbol
        }
        
        if(Win(Computer.getCompShips())) {
            System.out.println("You destroyed all of the AI's ships!");
            System.out.println("YOU WIN.\n");
            System.out.println("Thank you for playing.");
            Sound.Init(3);//win sound
            sound.Start();
            text.Character(1);
            text.Win();
            GamePlay gameplay = new GamePlay();
            gameplay.loops = false;
        }
    }
    
    private boolean CheckMatch(int row, int col) {
        boolean valid = false;
        if(row < 0 || row > 9 || col < 0 || col > 9) {//out of bounds
            valid = false;
        } else {
            if(Computer.getAIDisplay()[row][col] != 0) {//already determined as a hit/miss
                System.out.println("You've already fired at this location...");
                System.out.println("Please choose another coordinate next time.");
                valid = false;
            } else {
                System.out.println("You loaded the cannon ball and fired...");
                System.out.println("BOOM!!!");
                valid = true;
            }
        }
        return valid;
    }
    
    private boolean Win(ArrayList<Ship> ship) {
        boolean PlayerWins = false;
        int shipsDestroyed = 0;
        for(int i = 0; i < ship.size(); i++) {
            if(ship.get(i).isAlive() == false) {
                shipsDestroyed++;
            }
        }
        if(shipsDestroyed == 5) {
            PlayerWins = true;
        } else {
            PlayerWins = false;
        }
        
        return PlayerWins;
    }
    
    private void ShipDestroyed(Ship ship, int type) throws IOException {
        if(ship.getShipHits() >= ship.size) {
            Sound.Init(2);//destroyed sound
            sound.Start();
            System.out.println("You destroyed the AI's " + ship.name + ".");
            ship.setIsAlive(false);
            text.Character(1);
            text.Destroyed();
            text.ShipName(type);
        }
    }
}
