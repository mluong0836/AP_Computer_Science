/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package battleship;

/**
 *
 * @author dong
 */
public class Cruiser extends Ship{

    private int size;
    private int CruiserShipHits = 0;
    
    public Cruiser(String Name, boolean Alive, int xLoc, int yLoc, int Rotation, int Size) {
        super(Name, Alive, xLoc, yLoc, Rotation, Size);
        this.size = 3;
    }
    
    @Override
    public int getShipHits() {
        return this.CruiserShipHits;
    }
    
    @Override
    public int setShipHits(int hits) {
        return this.CruiserShipHits = hits;
    }
    
    public int getSize() {
        return this.size;
    }

    public void setSize(int size) {
        this.size = size;
    }
}
