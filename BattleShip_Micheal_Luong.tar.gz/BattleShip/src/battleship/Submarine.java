/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package battleship;

/**
 *
 * @author dong
 */
public class Submarine extends Ship{

    int size;
    private int SubmarineHits = 0;
    
    public Submarine(String Name, boolean Alive, int xLoc, int yLoc, int Rotation, int Size) {
        super(Name, Alive, xLoc, yLoc, Rotation, Size);
        this.size = 3;
    }

    @Override
    public int getShipHits() {
        return this.SubmarineHits;
    }
    
    @Override
    public int setShipHits(int hits) {
        return this.SubmarineHits = hits;
    }
    
    public int getSize() {
        return this.size;
    }

    public void setSize(int size) {
        this.size = size;
    }
    
}
