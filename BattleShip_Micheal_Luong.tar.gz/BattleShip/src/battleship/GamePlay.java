/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package battleship;

import java.io.IOException;

/**
 *
 * @author dong
 */
public class GamePlay {

    public Player player = new Player();
    public Computer comp = new Computer();
    public Grid grid = new Grid();
    public TimerForMusic timer = new TimerForMusic(false);
    public boolean loops = true;
    public BackGroundMusic music = new BackGroundMusic();

    public void Game() throws InterruptedException, IOException {

        BackGroundMusic.Init();
        music.Start();
        timer.Init();
        
        while (loops) {//loops the game

            CheckMusic();
            /*Prints player's map and guessing map*/
            System.out.println("Player's Map and Turn");
            //grid.printPlayerMap();
            grid.printAiHitMissMap();
            CheckMusic();
            
            /*Player is first*/
            player.Pturn();
            CheckMusic();
            
            grid.printAiHitMissMap();
            //grid.printAiHitMissMap();

            /*Ai's Turn*/
            System.out.println("Computer");
            CheckMusic();
            comp.AiTurn();
            CheckMusic();
            grid.printPlayerMap();

            CheckMusic();
        }

        BattleShip_Micheal_Luong.gameplay = false;
        music.Stop();
    }

    private void CheckMusic() throws IOException {
        if (timer.isRerun()) {//if true
            timer.setRerun(false);
            timer.setSecondsPassed(0);
            BackGroundMusic.Init();
            music.Start();
        }
    }
}
