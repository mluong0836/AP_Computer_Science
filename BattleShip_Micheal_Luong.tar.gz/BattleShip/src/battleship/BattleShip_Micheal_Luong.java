/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package battleship;

import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author dong
 */

public class BattleShip_Micheal_Luong {

    static Scanner scan = new Scanner(System.in);
    static boolean gameplay = true;
    public static Grid grid = new Grid();
    public static Computer comp = new Computer();
//    static Sound sound = new Sound(); 
//    static BackGroundMusic music = new BackGroundMusic();
    
    public static void main(String[] args) throws InterruptedException, IOException {
        Intro();
        while (gameplay) {
            System.out.println("What would you like to do?");
            System.out.println("(1) Read the rule book");
            System.out.println("(2) Start the game");
            System.out.println("(3) QUIT");
            int choice;
            choice = scan.nextInt();
            if (choice == 1) {
                RuleBook();
            } else if (choice == 2) {
                System.out.println("OK. Let's get started: ");
                Start();
            } else if (choice == 3) {
                System.out.println("Thank you for not trying... \n >.<");
                gameplay = false;
            } else {
                System.out.println("I don't understand.");
                System.out.println("Please reread the prompt and type in a valid response...");
            }
        }
    }

    private static void Intro() throws InterruptedException {
        System.out.println("Hello...");
        Thread.sleep(1000);
        System.out.println("Today you will be playing a classic game of BattleShip!");
        Thread.sleep(2000);
        System.out.println("BattleShip is one of the greatest games if you have the patience to play it. ");
        Thread.sleep(3500);
        System.out.println("This program was made by your Sponser Micheal Luong because he had ");
        Thread.sleep(2000);
        System.out.println("to stay in the hotel room waiting in San Francisco.");
        Thread.sleep(1000);
        for(int i = 0; i < 20; i++) {
            System.out.print(Color.CYAN + "." + Color.RESET);
            Thread.sleep(500);
        }
        System.out.println("\n\n\n\n\n");
    }

    private static void RuleBook() throws InterruptedException {
        Thread.sleep(1000);
        System.out.println("_______SUMMARY________");
        Thread.sleep(1000);
        System.out.println("Battle Ship is a guessing game of two players, in this case Player and AI.");
        Thread.sleep(2000);
        System.out.println("Your Objective is to correctly pinpoint the AI's ship coordinates. ");
        Thread.sleep(3500);
        System.out.println("Each person will take their guess and will be notified if it is a hit/miss/destroyed ship.");
        Thread.sleep(1000);
        System.out.println("___________________________________________________________________________");
        System.out.println("\n");
        
        Thread.sleep(1000);
        System.out.println("_________SHIP SIZES_________");
        Thread.sleep(1000);
        System.out.println("Each ship has a different size, which means it can endure more hits and take up more space on the board.");
        Thread.sleep(4000);
        System.out.println("There is a Destroyer(2), Cruiser(3), Submarine(3), AirCraft Carrier(5), and Battle Ship(4)");
        Thread.sleep(1000);
        System.out.println("__________________________________________________________________________________________________________");
        System.out.println("\n");
        
        Thread.sleep(1000);
        System.out.println("_________GAMEPLAY INSTRUCTIONS________");
        Thread.sleep(1000);
        System.out.println("You will be asked for a row and a column coodinate respectively.");
        Thread.sleep(2000);
        System.out.println("You are to guess within a range of 1 through 10.");
        Thread.sleep(2000);
        System.out.println("The purple colored board represents your originally set up board.");
        Thread.sleep(3000);
        System.out.println("This will show the 5 original ships you've added and displays");
        Thread.sleep(500);
        System.out.println("the hits and misses that the AI has inflicted.");
        Thread.sleep(2000);
        System.out.println("The yellow board represents your \\\"guesses\\\" and hits/misses that you've inflicted.");
        Thread.sleep(4000);
        System.out.println("________________________________________________________________________________________");
        System.out.println("\n");
        Thread.sleep(1000);
        System.out.println("ENJOY!");
        Thread.sleep(5000);
        System.out.println("\n\n\n\n");
    }

    private static void Start() throws InterruptedException, IOException {
        boolean end = false;
        
        int choicerow, choicecol, rotation=2;
        String[] names = {"Aircraft Carrier", "Battle Ship", "Cruiser", "Destroyer", "Submarine"};
        int totalShips = 0;
        while (!end) {
            if (totalShips <= 4) {
                System.out.println("Pick a coordinate for your " + names[totalShips] + ".");
                System.out.println("Pick a row from 1 through 10.");
                choicerow = scan.nextInt() - 1;
                System.out.println("Pick a column from 1 through 10.");
                choicecol = scan.nextInt() - 1;
                System.out.println("The default location is up, but what position do you want your " +
                        names[totalShips] + " to face.");
                System.out.println("(1) Default \n (2) Down \n (3) Left \n (4) Right");
                rotation = scan.nextInt();
                if(grid.CheckBoundaries(choicerow, choicecol, rotation, totalShips + 1)) {//valid boundary
                    if(grid.CheckInputMatching(choicerow, choicecol, rotation, totalShips + 1)) {
                        totalShips++;
                        grid.CreateShips(totalShips, choicerow, choicecol, rotation);
                    } else {
                        if(grid.match) {//there was a match
                            System.out.println("You already have a ship at that location.");
                            System.out.println("Please choose another location to place your "  + names[totalShips] + ".");
                            grid.match = false;
                        } else {
                            System.out.println("Insufficient space/beyond boundaries.");
                        }
                    }
                } else {
                    System.out.println("Insufficient space/beyond boundaries.");
                }        
            } else {
                end = true;
                grid.Init();//prepares player's stats
                comp.CompInit();//prepares computer's stats
                grid.printAiHitMissMap();
            } 
        }
        
        GamePlay game = new GamePlay();
        game.loops = true;
        game.Game();
    }
}
