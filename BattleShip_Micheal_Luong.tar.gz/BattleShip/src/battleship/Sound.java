/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package battleship;

    import sun.audio.*;    //import the sun.audio package
    import java.io.*;

/**
 *
 * @author dong
 */
public class Sound {
    
    public static AudioStream as;
    
    public static void Init(int type) throws FileNotFoundException, IOException {
        if(type == 1) {
            InputStream in = new FileInputStream(new File("music/Fire.wav"));
            AudioStream fire = new AudioStream(in); 
            Sound.as = fire;
        } else if(type == 2) {
            InputStream in = new FileInputStream(new File("music/Destroy.wav"));
            AudioStream destroy = new AudioStream(in);
            Sound.as = destroy;
        } else if(type == 3) {
            InputStream in = new FileInputStream(new File("music/Win.wav"));
            AudioStream win = new AudioStream(in);
            Sound.as = win;
        } else if(type == 4) {
            InputStream in = new FileInputStream(new File("music/Lose.wav"));
            AudioStream lose = new AudioStream(in);
            Sound.as = lose;
        }
    }
    
    public void Start() {
        AudioPlayer.player.start (as);
    }
    
// Similarly, to stop the audio.

    public void Stop() {
        AudioPlayer.player.stop (as);
    }
}
