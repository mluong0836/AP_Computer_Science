/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package battleship;

/**
 *
 * @author dong
 */
public class Ansi_Art {

    public void Lose() {
        System.out.println("     )             (                     \n"
                + "  ( /(             )\\ )                  \n"
                + "  )\\())       (   (()/(             (    \n"
                + " ((_)\\  (    ))\\   /(_))  (   (    ))\\   \n"
                + "__ ((_) )\\  /((_) (_))    )\\  )\\  /((_)  \n"
                + "\\ \\ / /((_)(_))(  | |    ((_)((_)(_))    \n"
                + " \\ V // _ \\| || | | |__ / _ \\(_-</ -_)   \n"
                + "  |_| \\___/ \\_,_| |____|\\___//__/\\___|   \n"
                + "                                         ");
    }

    public void Win() {
        System.out.println(" _  _  __   _  _    _  _  __  __ _       \n"
                + "( \\/ )/  \\ / )( \\  / )( \\(  )(  ( \\      \n"
                + " )  /(  O )) \\/ (  \\ /\\ / )( /    /      \n"
                + "(__/  \\__/ \\____/  (_/\\_)(__)\\_)__)      ");
    }

    public void Hit() {
        System.out.println(Color.RED + "    )  (             \n" + Color.RED
                + " ( /(  )\\ )  *   )   \n" + Color.RED
                + " )\\())(()/(` )  /(   \n" + Color.RED
                + "((_)\\  /(_))( )(_))  \n" + Color.RED
                + " _((_)(_)) (_(_())   \n" + Color.RED
                + "| || ||_ _||_   _|   \n" + Color.RED
                + "| __ | | |   | |     \n" + Color.RED
                + "|_||_||___|  |_|     \n" + Color.RED
                + "                     " + Color.RESET);
    }

    public void ShipName(int type) {
        if (type == 1) {
            System.out.println(Color.PURPLE + "                                                                                      \n"
                    + "   (                (              (        )     (                                   \n" + Color.PURPLE
                    + "   )\\    (   (      )\\   (       ) )\\ )  ( /(     )\\      )  (    (   (     (   (     \n" + Color.PURPLE
                    + "((((_)(  )\\  )(   (((_)  )(   ( /((()/(  )\\())  (((_)  ( /(  )(   )(  )\\   ))\\  )(    \n" + Color.PURPLE
                    + " )\\ _ )\\((_)(()\\  )\\___ (()\\  )(_))/(_))(_))/   )\\___  )(_))(()\\ (()\\((_) /((_)(()\\   \n" + Color.PURPLE
                    + " (_)_\\(_)(_) ((_)((/ __| ((_)((_)_(_) _|| |_   ((/ __|((_)_  ((_) ((_)(_)(_))   ((_)  \n" + Color.PURPLE
                    + "  / _ \\  | || '_| | (__ | '_|/ _` ||  _||  _|   | (__ / _` || '_|| '_|| |/ -_) | '_|  \n" + Color.PURPLE
                    + " /_/ \\_\\ |_||_|    \\___||_|  \\__,_||_|   \\__|    \\___|\\__,_||_|  |_|  |_|\\___| |_|    \n" + Color.PURPLE
                    + "                                                                                      " + Color.RESET);
        } else if (type == 2) {
            System.out.println(Color.GREEN + "                                  (                    \n" + Color.GREEN
                    + "   (            )    )  (         )\\ )    )            \n" + Color.GREEN
                    + " ( )\\     )  ( /( ( /(  )\\   (   (()/( ( /( (          \n" + Color.GREEN
                    + " )((_) ( /(  )\\()))\\())((_) ))\\   /(_)))\\()))\\  `  )   \n" + Color.GREEN
                    + "((_)_  )(_))(_))/(_))/  _  /((_) (_)) ((_)\\((_) /(/(   \n" + Color.GREEN
                    + " | _ )((_)_ | |_ | |_  | |(_))   / __|| |(_)(_)((_)_\\  \n" + Color.GREEN
                    + " | _ \\/ _` ||  _||  _| | |/ -_)  \\__ \\| ' \\ | || '_ \\) \n" + Color.GREEN
                    + " |___/\\__,_| \\__| \\__| |_|\\___|  |___/|_||_||_|| .__/  \n" + Color.GREEN
                    + "                                               |_|     " + Color.RESET);
        } else if (type == 3) {
            System.out.println(Color.CYAN + "                                      \n" + Color.CYAN
                    + "   (                                  \n" + Color.CYAN
                    + "   )\\   (      (   (         (   (    \n" + Color.CYAN
                    + " (((_)  )(    ))\\  )\\  (    ))\\  )(   \n" + Color.CYAN
                    + " )\\___ (()\\  /((_)((_) )\\  /((_)(()\\  \n" + Color.CYAN
                    + "((/ __| ((_)(_))(  (_)((_)(_))   ((_) \n" + Color.CYAN
                    + " | (__ | '_|| || | | |(_-</ -_) | '_| \n" + Color.CYAN
                    + "  \\___||_|   \\_,_| |_|/__/\\___| |_|   \n" + Color.CYAN
                    + "                                      " + Color.RESET);
        } else if (type == 4) {
            System.out.println(Color.YELLOW + " (                                               \n" + Color.YELLOW
                    + " )\\ )               )                            \n" + Color.YELLOW
                    + "(()/(     (      ( /( (         (       (   (    \n" + Color.YELLOW
                    + " /(_))   ))\\ (   )\\()))(    (   )\\ )   ))\\  )(   \n" + Color.YELLOW
                    + "(_))_   /((_))\\ (_))/(()\\   )\\ (()/(  /((_)(()\\  \n" + Color.YELLOW
                    + " |   \\ (_)) ((_)| |_  ((_) ((_) )(_))(_))   ((_) \n" + Color.YELLOW
                    + " | |) |/ -_)(_-<|  _|| '_|/ _ \\| || |/ -_) | '_| \n" + Color.YELLOW
                    + " |___/ \\___|/__/ \\__||_|  \\___/ \\_, |\\___| |_|   \n" + Color.YELLOW
                    + "                                |__/             " + Color.RESET);
        } else if (type == 5) {
            System.out.println(Color.GREEN + "  (                                                   \n" + Color.GREEN
                    + " )\\ )          )                                     \n" + Color.GREEN
                    + "(()/(   (   ( /(     )       )  (   (            (   \n" + Color.GREEN
                    + " /(_)) ))\\  )\\())   (     ( /(  )(  )\\   (      ))\\  \n" + Color.GREEN
                    + "(_))  /((_)((_)\\    )\\  ' )(_))(()\\((_)  )\\ )  /((_) \n" + Color.GREEN
                    + "/ __|(_))( | |(_) _((_)) ((_)_  ((_)(_) _(_/( (_))   \n" + Color.GREEN
                    + "\\__ \\| || || '_ \\| '  \\()/ _` || '_|| || ' \\))/ -_)  \n" + Color.GREEN
                    + "|___/ \\_,_||_.__/|_|_|_| \\__,_||_|  |_||_||_| \\___|  \n" + Color.GREEN
                    + "                                                     " + Color.RESET);
        }
    }

    public void Destroyed() {
        System.out.println(Color.RED + " (                                                 \n" + Color.RED
                + " )\\ )               )                       (      \n" + Color.RED
                + "(()/(     (      ( /( (         (       (   )\\ )   \n" + Color.RED
                + " /(_))   ))\\ (   )\\()))(    (   )\\ )   ))\\ (()/(   \n" + Color.RED
                + "(_))_   /((_))\\ (_))/(()\\   )\\ (()/(  /((_) ((_))  \n" + Color.RED
                + " |   \\ (_)) ((_)| |_  ((_) ((_) )(_))(_))   _| |   \n" + Color.RED
                + " | |) |/ -_)(_-<|  _|| '_|/ _ \\| || |/ -_)/ _` |   \n" + Color.RED
                + " |___/ \\___|/__/ \\__||_|  \\___/ \\_, |\\___|\\__,_|   \n" + Color.RED
                + "                                |__/               " + Color.RESET);
    }

    public void Character(int player) {
        if (player == 1) {
            System.out.println("  ____  _                       \n"
                    + " |  _ \\| | __ _ _   _  ___ _ __ \n"
                    + " | |_) | |/ _` | | | |/ _ \\ '__|\n"
                    + " |  __/| | (_| | |_| |  __/ |   \n"
                    + " |_|   |_|\\__,_|\\__, |\\___|_|   \n"
                    + "                |___/           ");
        } else {
            System.out.println("     _    ___ \n"
                    + "    / \\  |_ _|\n"
                    + "   / _ \\  | | \n"
                    + "  / ___ \\ | | \n"
                    + " /_/   \\_\\___|\n"
                    + "              ");
        }
    }

    public void Miss() {
        System.out.println(Color.CYAN + "888b     d888 8888888 .d8888b.   .d8888b.  \n" + Color.CYAN 
                + "8888b   d8888   888  d88P  Y88b d88P  Y88b \n"+ Color.CYAN
                + "88888b.d88888   888  Y88b.      Y88b.      \n"+ Color.CYAN
                + "888Y88888P888   888   \"Y888b.    \"Y888b.   \n"+ Color.CYAN
                + "888 Y888P 888   888      \"Y88b.     \"Y88b. \n"+ Color.CYAN
                + "888  Y8P  888   888        \"888       \"888 \n"+ Color.CYAN
                + "888   \"   888   888  Y88b  d88P Y88b  d88P \n"+ Color.CYAN
                + "888       888 8888888 \"Y8888P\"   \"Y8888P\"  \n"+ Color.CYAN
                + "                                           \n"+ Color.CYAN
                + "                                           \n"+ Color.CYAN
                + "                                           " + Color.RESET);
    }
}
