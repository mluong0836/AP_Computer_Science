/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/********************************************************************************
 * Program Filename: Animal.java
 * Author: Luong, Micheal
 * Date: 
 * Description: 
 * Input:
 * Output:
 ********************************************************************************/

package linkedlist_micheal_luong;

/**
 *
 * @author micheal
 */
public class Character {
    private String name;
    private String species;
    private String ability;
    private int strength;

    public Character(String name, String species, String ability, int strength) {
        this.name = name;
        this.species = species;
        this.ability = ability;
        this.strength = strength;
    }

    public String getName() {
        return name;
    }

    public String getSpecies() {
        return species;
    }

    public String getAbility() {
        return ability;
    }

    public int getStrength() {
        return strength;
    }
    
    public void Show() {
        System.out.println("Name: " + this.name);
        System.out.println("Species: " + this.species);
        System.out.println("Ability: " + this.ability);
        System.out.println("Strength: " + this.strength);
    }
    
}

