/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/********************************************************************************
 * Program Filename: Animal.java
 * Author: Luong, Micheal
 * Date: 
 * Description: 
 * Input: 
 * Output: 
 ********************************************************************************/

package linkedlist_micheal_luong;

    import java.util.Scanner;

/**
 *
 * @author micheal
 */
public class LinkedList_Micheal_Luong {

    /**
     * @param args the command line arguments
     */
    
    static Scanner scan = new Scanner(System.in);
    
    public static void main(String[] args) throws InterruptedException {
        
          LinkedList L = new LinkedList();
        
        System.out.println("You are responsible for recording and reviewing all of the different \n"
                + "monsters, superheros, and wizards in the universe.");
        
        boolean gameplay = true;
        L.l.init();
        while(gameplay) {
            
            System.out.println("What would you like to do?");
        
            System.out.println("(1) Add a superhero, wizard, or monster.");
            System.out.println("(2) Remove the first superhero, wizard, or monster on your list.");
            System.out.println("(3) Remove the last superhero, wizard, or monster on your list.");
            System.out.println("(4) QUIT");
        
            int choice;
            choice = scan.nextInt();
        
            if(choice == 1) {
                System.out.println("You are opening your catalog...\n\n\n");
                System.out.println("You take your pen out and start examining the new character.");
                System.out.println("What is this character's name?");
                scan.nextLine();
                String name;
                name = scan.nextLine();
                System.out.println("What type of species is it?");
                String species;
                species = scan.nextLine();
                System.out.println("What is this character's special ability?");
                String ability;
                ability = scan.nextLine();
                System.out.println("From a scale of 0 to 100, what danger rating would you give " + name + ".");
                int danger;
                danger = scan.nextInt();
                L.l.add(new Character(name, species, ability, danger), 1);
            } else if(choice == 2) {
                System.out.println("You open up your catelog and scratched out the first character...");
                L.l.deleteNodeAtIndex(1);
            } else if(choice == 3) {
                System.out.println("You open up your catelog from the back and remove the last name...");
                L.l.deleteNodeAtIndex(L.l.listCount);
            } else if(choice == 4) {
                gameplay = false;
            } else {
                System.out.println("I don't understand what you want to do...");
            }
                        
            if(gameplay) {
                
                for(int i = 0; i < 100; i++) {
                    System.out.println("");
                }
                
                L.l.show();
            }           
        }        
    }
}