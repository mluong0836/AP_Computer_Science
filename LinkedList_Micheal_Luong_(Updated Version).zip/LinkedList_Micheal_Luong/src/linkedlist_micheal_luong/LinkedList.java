/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/********************************************************************************
 * Program Filename: Animal.java
 * Author: Luong, Micheal
 * Date: 
 * Description: 
 * Input: 
 * Output: 
 ********************************************************************************/

package linkedlist_micheal_luong;

/**
 *
 * @author micheal
 */
public class LinkedList {
    public Node head;
    public int listCount;
    public static LinkedList l =  new LinkedList();
    
    public LinkedList() {
        this.head = new Node(null);
        this.listCount = 0;
    }
    
    public static void init () throws InterruptedException {
        Character Superman = new Character("Superman", "Human hero", "Heat Vision", 75);
        Character Gandalf = new Character("Gandalf", "Wizard", "Fire and Light manipulations", 50);
        Character Hydra = new Character("Hydra", "Monster", "Regenerates multiple heads", 100);
        Character Spiderman = new Character("Spiderman", "Human hero", "Shoots out webs", 35);
        Character Chimera = new Character("Chimera", "Monster", "Spits out fire", 40);
        l.add(Superman);
        l.add(Gandalf);
        l.add(Hydra);
        l.add(Spiderman);
        l.add(Chimera);
        l.show();
    }
    
    /****************************************************************************
     * Method: The method name is getFoodamt
     * Description: getter to return the food amount
     * Parameters: none
     * Pre-Conditions: Player decides to showcase animals
     * Post-Conditions: The food amount will be returned
     ****************************************************************************/
    
    public void show() throws InterruptedException {
        Node current = head;
        while(current.next != null) {
            System.out.println("______________________________________________");
            System.out.print("NAME: " + current.next.character.getName() + "\n" +
                    "Species: " + current.next.character.getSpecies() + "\n" +
                    "Ability: " + current.next.character.getAbility() + "\n" + 
                    "Strength: " + current.next.character.getStrength() + "\n");
            current = current.next;//goes to the next node
            System.out.println("______________________________________________");
            Thread.sleep(1000);
        }
        
        if(listCount == 0) {
            System.out.println("Your list is empty.");
            System.out.println("Nothing to be displayed...");
        }
        
        //System.out.println(current.data);
        System.out.println("\n\n\n\n\n");
    }
    
    /****************************************************************************
     * Method: The method name is getFoodamt
     * Description: getter to return the food amount
     * Parameters: none
     * Pre-Conditions: Player decides to showcase animals
     * Post-Conditions: The food amount will be returned
     ****************************************************************************/
    
    public boolean add(Character d){
    	Node end = new Node(d);
    	Node current = head;

    	while(current.next != null){
    		current = current.next;
    	}
    	current.next = end;
    	listCount++;
        System.out.println(d.getName() +" appended to tail!");
        return true;
    }

    /****************************************************************************
     * Method: The method name is getFoodamt
     * Description: getter to return the food amount
     * Parameters: none
     * Pre-Conditions: Player decides to showcase animals
     * Post-Conditions: The food amount will be returned
     ****************************************************************************/
    
    public boolean add(Character d,int index){
    	Node end = new Node(d);
    	Node current = head;
    	int jump;

//    	if(index>listCount || index<1){
//                l.add(d);//player has deleted all of the characters and index is back to zero, so go back to the regular add function
//    		return false;
//    	}
//    	else{
    		jump = 0;
                //similar to selection sort
    		while(jump<index-1){
    			current = current.next;
    			jump++;
    		}
    		end.next = current.next;
    		current.next = end;
    		listCount++;
    		System.out.println("Success! "+d.getName()+" added at index "+index);
            return true;
//    	}
    }

    
//    public boolean deleteNodeWithData(int d){
//    	Node current = head;
//        while(current.next!=null){
//            if(current.next.data==d){
//                current.next = current.next.next;
//                listCount--;
//                System.out.println("Success! Node with data "+d+" deleted.");
//                return true;
//            }
//            current = current.next;
//        }
//        System.out.println("Delete Failed: No node found with given data!");
//        return false;
//    }

    public boolean deleteNodeAtIndex(int index){
    	Node current = head;
    	int jump;
    	if(index>listCount || index<1){
    		System.out.println("Delete Failed: index out of bounds of size of linked list!!");
    		return false;
    	}    	
    	else{
    		jump=0;
    		while(jump<index-1){
    			current = current.next;
    			jump++;
    		}
    		current.next = current.next.next;
    		System.out.println("Success! Node at index "+index+" deleted.");
    		listCount--;
    		return true;
    	}
    }
}
