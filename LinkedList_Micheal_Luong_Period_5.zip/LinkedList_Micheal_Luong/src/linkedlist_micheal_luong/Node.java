/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/********************************************************************************
 * Program Filename: Node.java
 * Author: Luong, Micheal
 * Date: 12/8/16
 * Description: This represents my scratched Node class. A node is similar to a 
 *              point in a LinkedList. Here, I made the basic template to be used
 *              to add multiple nodes in the linkedlist that I created.
 * Input: LinkedList_Micheal_Luong.java, Character.java
 * Output: LinkedList.java
 ********************************************************************************/

package linkedlist_micheal_luong;

/**
 *
 * @author micheal
 */

public class Node {
    Node next = null;//the next node is null, since it is null-terminated
    int data;
    Character character;//object of Character, which each node will encompass
    
    /*class constructor to serve as basic template of a node, which will be created in the LinkedList class. Holds a character/object parameter*/
    public Node(Character d) {
        character = d;
    }
}