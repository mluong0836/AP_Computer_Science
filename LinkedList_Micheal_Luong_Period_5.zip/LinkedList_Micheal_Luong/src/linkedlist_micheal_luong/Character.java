/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/********************************************************************************
 * Program Filename: Character.java
 * Author: Luong, Micheal
 * Date: 12/6/16
 * Description: This class was created for the purpose of future creations of   
 *              multiple characters. This serves as the basic template for the 
 *              added characters, such as its name, species, ability, and danger
 *              level. It also contains several getters to get the name, species,
 *              ability, and danger level of each character, which in return is 
 *              printed out on the screen.
 * Input: keyboard
 * Output: LinkedList.java
 ********************************************************************************/

package linkedlist_micheal_luong;

/**
 *
 * @author micheal
 */
public class Character {
    private String name;
    private String species;
    private String ability;
    private int strength;

    public Character(String name, String species, String ability, int strength) {
        this.name = name;
        this.species = species;
        this.ability = ability;
        this.strength = strength;
    }

    /****************************************************************************
     * Method: getName
     * Description: This is a getter to get the object's name
     * Parameters: none
     * Pre-Conditions: The method show has to be called before this is called.
     * Post-Conditions: The program will have the Object's name.
     ****************************************************************************/
    
    public String getName() {
        return name;
    }

    /****************************************************************************
     * Method: getSpecies
     * Description: This is a getter method to get the Object's species type
     * Parameters: none
     * Pre-Conditions: The method show has to be called before this is called.
     * Post-Conditions: The program will have the Object's species type.
     ****************************************************************************/
    public String getSpecies() {
        return species;
    }

    /****************************************************************************
     * Method: getAbility
     * Description: This is a getter method to get the object's ability.
     * Parameters: none
     * Pre-Conditions: The method show has to be called before this is able to 
     *                 initiate.
     * Post-Conditions: The program will have the Object's ability.
     ****************************************************************************/
    public String getAbility() {
        return ability;
    }

    /****************************************************************************
     * Method: getStrength
     * Description: This is a getter method to get the Object's strength level,
     *              which is from 0 to 100.
     * Parameters: none
     * Pre-Conditions: The method show has to already been called. 
     * Post-Conditions: the program will have the Object's strength
     ****************************************************************************/
    public int getStrength() {
        return strength;
    }
   
}

