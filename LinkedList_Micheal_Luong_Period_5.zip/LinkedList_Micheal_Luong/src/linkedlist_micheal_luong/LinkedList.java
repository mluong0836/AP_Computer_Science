/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/********************************************************************************
 * Program Filename: LinkedList.java
 * Author: Luong, Micheal
 * Date: 12/13/16
 * Description: This class is where the creation of the Linked list from scratch
 *              occurs. There are add, remove, and show methods, which is similar
 *              in function to the add, remove, and display function in the built
 *              in linkedlist class. In addition, this is where the 5 pre-characters
 *              are added as well.
 * Input: keyboard, TextColor.java, Node.java, and LinkedList.java
 * Output: LinkedList_Micheal_Luong.java, and console
 ********************************************************************************/

package linkedlist_micheal_luong;

    import java.util.Scanner;

/**
 *
 * @author micheal
 */
public class LinkedList {
    public Node head;//create a Node object called head, this is the first node
    public int listCount;//this variable will store the size of the list
    public static LinkedList link =  new LinkedList();//creates a new LinkedList object
    
    public LinkedList() {
        this.head = new Node(null);//set the first head to be null, since this is a null-terminated linked list
        this.listCount = 0;//sets the size to zero
    }
    
    /****************************************************************************
     * Method: init
     * Description: This method is for adding the 5 default characters in the link
     *              list. It first creates 5 character objects and then adds them
     *              to 5 nodes, each linking in front of each other. Then a show
     *              method is called to display the 5 original characters.
     * Parameters: none
     * Pre-Conditions: The game must have started and the intro story completed.
     * Post-Conditions: You will have 5 initialized characters that are added to    
     *                  your new linkedlist.
     ****************************************************************************/
    
    public static void init () throws InterruptedException {
        /*creates 5 new character objects*/
        Character Superman = new Character("Superman", "Human hero", "Heat Vision", 85);
        Character Gandalf = new Character("Gandalf", "Wizard", "Fire and Light manipulations", 50);
        Character Hydra = new Character("Hydra", "Monster", "Regenerates multiple heads", 90);
        Character Spiderman = new Character("Spiderman", "Human hero", "Shoots out webs", 35);
        Character Chimera = new Character("Chimera", "Monster", "Spits out fire", 40);
        
        /*adds character objects to linkedlist object called link*/
        link.addBehind(Superman);
        link.addBehind(Gandalf);
        link.addBehind(Hydra);
        link.addBehind(Spiderman);
        link.addBehind(Chimera);
        
        link.show();//calls show method to print out the characters
    }
    
    /****************************************************************************
     * Method: show
     * Description: This method is responsible for printing out all the characters
     *              in my linkedlist. It iterates through until there's a null node
     *              and prints out the character's name, species, ability, and 
     *              danger rating through the getters that I created in my Character
     *              class.
     * Parameters: none
     * Pre-Conditions: There must be some object already in the linkedlist and the 
     *                 linkedlist link must have been declared and initialized.
     * Post-Conditions: There will be a list of all the character's attributes 
     *                  displayed on the console screen.
     ****************************************************************************/
    
    public void show() throws InterruptedException {
        Node current = head;//takes the current Node and sets it equal to head
        while(current.next != null) {//while the current node is not nullm then continue running the while loop to print out the characters
            System.out.println(TextColor.ANSI_YELLOW + "______________________________________________" + TextColor.ANSI_RESET);
            System.out.print(TextColor.ANSI_GREEN + "NAME: " + current.next.character.getName() + "\n" + TextColor.ANSI_RESET +
                    TextColor.ANSI_CYAN + "Species: " + current.next.character.getSpecies() + "\n" + TextColor.ANSI_RESET +
                    TextColor.ANSI_PURPLE + "Ability: " + current.next.character.getAbility() + "\n" + TextColor.ANSI_RESET + 
                    TextColor.ANSI_RED + "Strength: " + TextColor.ANSI_YELLOW + current.next.character.getStrength() + "\n" + TextColor.ANSI_RESET);
            current = current.next;//goes to the next node
            System.out.println(TextColor.ANSI_YELLOW + "______________________________________________" + TextColor.ANSI_RESET);
            Thread.sleep(600);//pauses for 600 milliseconds
        }
        
        /*if the listCount or size is equal to zero, then there isn't any characters; thus, print empty list.*/
        if(listCount == 0) {
            System.out.println("Your list is empty.");
            System.out.println("Nothing to be displayed...");
        }
        
        System.out.println("\n\n\n\n\n");
    }
    
    /****************************************************************************
     * Method: This method is called addBehind
     * Description: This method is used to add objects to the new nodes being 
     *              created at the end. This is used to add the characters in my 
     *              linkedlist at the end. Therefore, I will only use this method 
     *              once when adding the pre-default characters.
     * Parameters: Character d
     * Pre-Conditions: There must be an initialized character that is passed to 
     *                 this method. In addition, the method init must have already 
     *                 been called.
     * Post-Conditions: You will have a new node that stores the new character at 
     *                  the end of the list.
     ****************************************************************************/
    
    public boolean addBehind(Character d){
    	Node end = new Node(d);//creates a new node object and sets it equal to the declared Node end
    	Node current = head;//sets the current Node to head; thus, starting the iteration

    	while(current.next != null){//while the current head isn't null, then continue this while loop
            current = current.next;//set the current node equal to the next availabe node 
    	}
        
    	current.next = end;//when there is a null detected, get the previous node and set it equal to the new node. This adds it to the end of the lsit
    	listCount++;//alters the size by adding one
        return true;
    }

    /****************************************************************************
     * Method: add
     * Description: This method is used to add objects to the recently created 
     *              nodes at the beginning/in front of the linked list. This method
     *              is similar to an insertion sort because it iterates through the
     *              list of nodes and inserts the new node to the beginning of the 
     *              list. There is an end node, which is responsible for storing
     *              the new object that you wanted to add.
     * Parameters: Character d, and int index
     * Pre-Conditions: You must have already initialized the Character to be added
     *                 and player must have chosen choice 1. 
     * Post-Conditions: You will have added a new Node representing the character
     *                  in front of the list, or at the desired index. 
     ****************************************************************************/
    
    public boolean add(Character d,int index) throws InterruptedException {//recursively
        
    	Node front = new Node(d);//creates a new node called front, which in this case is added to the desired index
    	Node current = head;//sets Node current equal to head to start iterating through the linked list
    	int times;//variable to calculate how many times the while loop has iterated through to find out which index to add to

    	times = 0;
        
        
    	while(times<index-1){
            current = current.next;//sets current node equal to the next availabe node, until it reaches the desired index-1, which is in front of the positiion
            times++;//adds one to the numebr of index iterated over already
        }
        
        /*similar to an insertion sort, since it swaps the two Nodes*/
    	front.next = current.next;//sets the next node to the front Node equal to the current node 
    	current.next = front;//sets the next node equal to the front Node
    	listCount++;//expands list size
        System.out.println("Success! " + d.getName() + " has been added to your catalog.");
        Thread.sleep(2000);
        System.out.println("You locked up " + d.getName() + " in his cell.");
        Thread.sleep(3000);
        return true;
    }

    /****************************************************************************
     * Method: deleteNodeAtIndex
     * Description: This method will be used when the player decides to remove one
     *              of the characters. This method will have a while loop, which 
     *              will loop over the linked list and record the number of times
     *              it has to iterate through until it is behind the desired index.
     *              Then, the node at that position will be replaced with the node
     *              to the right; therefore, "deleting" the character.
     * Parameters: int index
     * Pre-Conditions: Player must have chose choice 2 or 3 in order for this method
     *                 to be called. 
     * Post-Conditions: The node at that location will be deleted, and the other 
     *                  nodes are moved down one index to fill in the "gap".
     ****************************************************************************/
    
    public boolean deleteNodeAtIndex(int index) throws InterruptedException{
    	Node current = head;//sets new declared current node equal to the head to start iteration
    	int counter;//counter to see how many indexes have been iterated
        
        /*The list is empty or isn't valid if the index is less than one or greater than the actual linkedlist size*/
    	if(index>listCount || index<1) {
    		System.out.println("Empty list");
                return false;
    	}    	
    	else{
    		counter=0;
                /*as long as the number of indexes looped over does not exceed the passed index value-1*/
    		while(counter<index-1){
    			current = current.next;//set the current node equal to the next available node
    			counter++;
    		}
                System.out.println("Success! You have deleted " + current.next.character.getName());
                Thread.sleep(2000);
                System.out.println(current.next.character.getName() + " has been executed...");
                Thread.sleep(3000);
    		current.next = current.next.next;//sets the next Node equal to the next next Node or two nodes in front. You do this to move all nodes back by one including the null node at then end
    		listCount--;//decreases node
    		return true;
    	}
    }
    
    /****************************************************************************
     * Method: addNewCharacter
     * Description: This method was established because I did not want main to be 
     *              so condensed with code. Therefore, when the player wants to 
     *              add a new character, the program will call this method which 
     *              has a series of questions to be answered. Based on the 
     *              recorded answers, this method will call the add method with
     *              the declared and initialized new Character to be added in the
     *              linkedlist.
     * Parameters: none
     * Pre-Conditions: Player must have chose choice 1 to be able to get to this 
     *                 method.
     * Post-Conditions: There will be a new Character object that will be passed to
     *                  the add function to be inserted in the linkedlist.
     ****************************************************************************/
    
    public void addNewCharacter() throws InterruptedException {
        Scanner scan = new Scanner(System.in);
        System.out.println("What is this character's name?");
        String name;
        name = scan.nextLine();
        System.out.println("What type of species is it?");
        String species;
        species = scan.nextLine();
        System.out.println("What is this character's special ability?");
        String ability;
        ability = scan.nextLine();
        System.out.println("From a scale of 0 to 100, what is " + name + " strength level.");
        int danger;
        danger = scan.nextInt();
        link.add(new Character(name, species, ability, danger), 1);
    }
}
