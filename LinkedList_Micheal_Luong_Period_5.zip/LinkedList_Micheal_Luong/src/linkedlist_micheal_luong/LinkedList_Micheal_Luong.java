/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/********************************************************************************
 * Program Filename: LinkedList_Micheal_Luong.java
 * Author: Luong, Micheal
 * Date: 12/5/16
 * Description: This is the main class, which is responsible for the introductory
 *              story as well as serve as the "driver class" as it decides what
 *              the player wants to do through the recorded choices and calls the    
 *              associated methods in response. This is a linked list 
 *              implementation from scratch.
 * Input: keyboard, LinkedList.java, TextColor.java
 * Output: console, LinkedList.java
 ********************************************************************************/

package linkedlist_micheal_luong;

    import java.util.Scanner;

/**
 *
 * @author micheal
 */

public class LinkedList_Micheal_Luong {

    /**
     * @param args the command line arguments
     */
    
    static Scanner scan = new Scanner(System.in);//scanner to record player's choices
    
    public static void main(String[] args) throws InterruptedException {
        
        LinkedList L = new LinkedList();//creates a new object LinkedList to reference the add, delete, and show methods
        
        Intro();//calls the intro method that gives us a storyline
        
        boolean gameplay = true;//sets gameplay loop to true
        
        L.link.init();//this init method will be responsible for creating/showing the 5 characters originally added at the start
        
        /*while loop that continues to loop the game until player quits*/
        while(gameplay) {
            
            System.out.println("What would you like to do?");
        
            System.out.println(TextColor.ANSI_GREEN + "(1) " + TextColor.ANSI_RESET + "Add a superhero, wizard, or monster.");
            System.out.println(TextColor.ANSI_PURPLE + "(2) " + TextColor.ANSI_RESET + "Remove the first superhero, wizard, or monster on your list.");
            System.out.println(TextColor.ANSI_CYAN + "(3) " + TextColor.ANSI_RESET + "Remove the last superhero, wizard, or monster on your list.");
            System.out.println(TextColor.ANSI_RED + "(4) " + TextColor.ANSI_RESET + "QUIT" + TextColor.ANSI_RESET);
        
            int choice;//this will hold the player's choice
            choice = scan.nextInt();//records the player's choice
        
            if(choice == 1) {//if player chose 1, then you call the addNewCharacter method
                System.out.println("You are opening your catalog...\n\n\n");
                System.out.println("You take your pen out and start examining the new character.");
                L.addNewCharacter();//this will bring up a series of questions for player to fill out 
            } else if(choice == 2) {//if player chose 2, then the first character in the first node is deleted
                System.out.println("You open up your catelog and scratched out the first character...");
                L.link.deleteNodeAtIndex(1);//deletes first character at index 1, since linkedlist start at 1 not zero because it's null-terminated
            } else if(choice == 3) {//if player chose 3, then the last character is deleted
                System.out.println("You open up your catelog from the back and remove the last name...");
                L.link.deleteNodeAtIndex(L.link.listCount);//finds the size of the list and deletes the character at that index/lst character
            } else if(choice == 4) {//player wants to quit
                gameplay = false;//ends the loop
            } else {//in case if player types random things....
                System.out.println("I don't understand what you want to do...");
            }
                   
            /*if the gameplay has not ended/false*/
            if(gameplay) {
                /*print 100 empty lines*/
                for(int i = 0; i < 100; i++) {
                    System.out.println("");
                }
                
                L.link.show();//shows all of the characters currently in the list
            }           
        }
        
        System.out.println("Thanks for your contributions to my Prison, but unfortunately we have to" + TextColor.ANSI_GREEN + " exterminate you...");
        Thread.sleep(1000);//pauses for 1 second/1000 milliseconds
        /*prints out 25 red colored dots*/
        for(int i = 0; i < 25; i++) {
            System.out.print(TextColor.ANSI_RED + ".");
            Thread.sleep(500);//sleeps for half a second
        }
        System.out.println("\n THE END");
    }
    
    /****************************************************************************
     * Method: The method is called Intro
     * Description: This method prints out the intro story that begins my program
     *              and uses a Thread.sleep to create a pause effect and has throws
     *              an InterruptedException as well.
     * Parameters: none
     * Pre-Conditions: The game must have started.
     * Post-Conditions: You will have several sentences displayed on the console 
     *                  screen that will introduce you to the game.
     ****************************************************************************/
    
    static void Intro() throws InterruptedException {
        System.out.println("Thank you for taking a job at Micheal's Wonderful Prison in London.");
        Thread.sleep(2000);//pauses for 2 seconds
        System.out.println("Your job is to take in all the heros, wizards, monsters, villains, etc...");
        Thread.sleep(3000);
        System.out.println("and record them in this catalog.");
        Thread.sleep(2000);        
        System.out.println("This will ensure that no one gets in or out without the peace keepers knowing.");
        Thread.sleep(3000);
        System.out.println("You will be paid $200 an hour if you maintain this job and not tell any one else, about our shady business.");
        Thread.sleep(4000);
        System.out.println("Also, if you and the peace keepers want to execute someone, ");
        Thread.sleep(3000);
        System.out.println("please remember to take out their names from the catalog that we will be giving you.");
        Thread.sleep(3000);
        System.out.println("Remember... You are responsible for recording and reviewing all of the different \n"
                + "monsters, superheros, and wizards in the universe.");
        Thread.sleep(5000);
        System.out.println("Do you have any other questions...");
        System.out.println("OK! Let's begin!\n\n\n\n\nn\n");
        Thread.sleep(3000);
    }
}