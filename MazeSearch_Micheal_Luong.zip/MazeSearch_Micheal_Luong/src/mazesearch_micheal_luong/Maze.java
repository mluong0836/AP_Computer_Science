/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/********************************************************************************
 * Program Filename: Maze.java
 * Author: Luong, Micheal
 * Date: 11/21/16
 * Description: This class is responsible for solving, printing, and recording 
 *              the maze solving as it progresses. This class holds a 2d int 
 *              array that will print out yellow integers as the original path, 
 *              red integers for uncorrect paths, and green integers for correct
 *              paths. In addition, this is where recursion is use to solve the
 *              maze.
 * Input: TextColor.java
 * Output: MazeSearch_Micheal_Luong.java
 ********************************************************************************/

package mazesearch_micheal_luong;

/**
 *
 * @author micheal
 */

public class Maze extends TextColor {
    private final int tried = 3;//this number represents tried paths
    private final int path = 7;//this number will symbolize correct paths

    /*declaring and initializing a 2d int array called grid. 0's are walls while 1's are open paths.*/
    int[][] grid = {{1,1,1,0,1,1,0,0,0,1,1,1,1},
                   {1,0,1,1,1,0,1,1,1,1,0,0,1},
                   {0,0,0,0,1,0,1,0,1,0,1,0,0},
                   {1,1,1,0,1,1,1,0,1,0,1,1,1},
                   {1,0,1,0,0,0,0,1,1,1,0,0,1},
                   {1,0,1,1,1,1,1,1,0,1,1,1,1},
                   {1,0,0,0,0,0,0,0,0,0,0,0,0},
                   {1,1,1,1,1,1,1,1,1,1,1,1,1}};
    
    
    /****************************************************************************
     * Method: The method name is toString
     * Description: This method is responsible for returning a String 
     *              representation of the 2d array with text colors depending if
     *              it is an original, tried, or path path.
     * Parameters: none
     * Pre-Conditions: You must already have declared a 2d array named grid.
     * Post-Conditions: You will have a 2d maze displayed on the console screen.
     ****************************************************************************/
    
    @Override
    public String toString() {
        
        System.out.println("\n\n");
        for(int row = 0; row < grid.length; row++) {
            for(int col = 0; col < grid[row].length; col++) {
                if(grid[row][col] == path) {
                    System.out.print(TextColor.ANSI_GREEN + grid[row][col] + TextColor.ANSI_RESET);
                } else if(grid[row][col] == tried) {
                    System.out.print(TextColor.ANSI_RED + grid[row][col] + TextColor.ANSI_RESET);
                } else {
                    System.out.print(TextColor.ANSI_YELLOW + grid[row][col] + TextColor.ANSI_RESET);
                }
            }
            System.out.println("");
        }
        System.out.println("\n\n");
        
        return null;
    }
    
    /****************************************************************************
     * Method: The method name is Traverse
     * Description: 
     * Parameters: int Row, int Col
     * Pre-Conditions: 
     * Post-Conditions: 
     ****************************************************************************/
    
    public boolean Traverse(int Row, int Col) throws InterruptedException {
        
        boolean finish = false;
        
        if(valid(Row, Col)) {
            grid[Row][Col] = tried;
        
            /*ends when the last location of the 2d array is located*/
            if(Row == grid.length - 1 && Col == grid[0].length - 1) {
                finish = true;
            } else {
            
                /*path checks the path in front(down)*/
                finish = Traverse(Row+1, Col);
                
                if(!finish) {//path checks the right path
                    finish = Traverse(Row, Col+1);
                }
            
                 if(!finish) {//path checks the path behind (up)
                    finish = Traverse(Row-1, Col);
                }
                
                if(!finish) {//path checks the left path
                    finish = Traverse(Row, Col-1);
                }               
            }
                
            /*if the boolean finish is true, then the correct pathway will be marked with a 7*/
            if(finish) {
                grid[Row][Col] = path;//marks correct
            }
            
            /*skips 100 lines*/
            for(int lines = 0; lines < 100; lines++) {
                System.out.println("");
            }
        }
        
        toString();
        Thread.sleep(500);
        return finish;
    }
    
    /****************************************************************************
     * Method: The method name is valid
     * Description: 
     * Parameters: int Row, int Col
     * Pre-Conditions: 
     * Post-Conditions: 
     ****************************************************************************/
    
    private boolean valid(int Row, int Col) throws InterruptedException {
        
        boolean end = false;
        
        /*Checks boundaries*/
        if(Row >= 0 && Row < grid.length && Col >= 0 && Col < grid[Row].length) {
            
            /*if there is an open path that isn't blocked by walls represented by zeros*/
            if(grid[Row][Col] == 1) {
                end = true;
            }
        }
        
        for(int skip = 0; skip < 100; skip++) {
            System.out.println("");
        }
        
        toString();
        Thread.sleep(500);
        toString();
        return end;
    }
}
