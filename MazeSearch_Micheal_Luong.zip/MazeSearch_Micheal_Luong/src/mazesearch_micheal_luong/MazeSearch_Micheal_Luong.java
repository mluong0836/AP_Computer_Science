/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/********************************************************************************
 * Program Filename: MazeSearch_Micheal_Luong.java
 * Author: Luong, Micheal
 * Date: 11/20/16
 * Description: This is the main class and is responsible for printing out the 2d
 *              maze as it is recursively solving itself, and in the end print 
 *              out a path of green 7's to represent the correct/solved path. In
 *              addition, there is also background music through the java built in
 *              io.* and sun.*.
 * Input: Maze.java
 * Output: Console
 ********************************************************************************/

package mazesearch_micheal_luong;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import sun.audio.AudioPlayer;
import sun.audio.AudioStream;

/**
 *
 * @author micheal
 */
public class MazeSearch_Micheal_Luong {

    /**
     * @param args the command line arguments
     * @throws java.lang.InterruptedException
     */
    static InputStream music;//new object of InputStream
        
    public static void main(String[] args) throws InterruptedException, FileNotFoundException, IOException {
        // TODO code application logic here

        music = new FileInputStream(new File("music/MazeMusic.wav"));//calls the file MazeMusic from the music folder
        AudioStream audios = new AudioStream(music);//creates a new AudioStream object
        AudioPlayer.player.start(audios);//starts the audio player
        
        Maze labyrinth = new Maze();//creates a new Maze object called labyrinth
        
        labyrinth.toString();//calls the method to print out original 2d maze
        
        /*calls the recursive method traverse with a y,x coordinate at (0,0); in other words, the starting point of the array*/
        if(labyrinth.Traverse(0, 0)) {//if this returns true, then it's solved
            System.out.println("Maze solved.");
            AudioPlayer.player.stop(audios);//stops the audio player
        } else {
            System.out.println("Maze is unsolvable.");
        }        
    }
}
