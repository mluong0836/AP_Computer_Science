/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connectfour_micheal_luong;
    import java.util.Scanner;

/**
 *
 * @author micheal
 */

public class ConnectFour_Micheal_Luong {

    /**
     * @param args the command line arguments
     */
    
    static Scanner scan = new Scanner(System.in);
    public static int wins = 0;
    public static int lose = 0;
    
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Welcome to the board game section.");
        System.out.println("Today you will be playing a classic game of Connect 4.");
        
        GamePlay game = new GamePlay();
        boolean gameplay = true;
        int answer; 
        
        while(gameplay) {
            System.out.println("Do you want to \n ");
            System.out.println("(1) Play");
            System.out.println("(2) Play best of 3");
            System.out.println("(3) Read the Rules");
            System.out.println("(4) Exit");
            
            answer = scan.nextInt();
            if(answer == 1) {
                game.Gameloop(answer);
            } else if(answer == 2) {
                while(wins < 2 && lose < 2) {//inner while loop  
                    game.Gameloop(answer);
                }
                gameplay = false;
            } else if(answer == 3) {
                Rule();
            } else if(answer == 4) {
                System.out.println("Thank you for not trying at all...");
                gameplay = false;
            } else {
                System.out.println("I don't understand what you are telling me...");
            }
        }
    }
    
    private static void Rule() {
        System.out.println("Here is the rules for connect four.");
    }
}
