/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connectfour_micheal_luong;

    import java.util.LinkedList;

/**
 *
 * @author micheal
 */

public class DisplayBoard {
    //public Player player = new Player("red");
   //public Computer Ai = new Computer("yellow");
    private LinkedList<Integer>[][] board = new LinkedList[6][7];
    
    public void Init() {
        for(int i = 0; i < 6; i++) {
            for(int j = 0; j < 7; j++) {
                board[i][j] = new LinkedList<>();
                board[i][j].add(0);//default open spaces
            }
        }
    }
    
    public void Reset() {
        for(int i = 0; i < 6; i++) {
            for(int j = 0; j < 7; j++) {
                board[i][j].clear();
            }
        }
    }
    
    public void Show() {
        for(int i = 0; i < 6; i++) {
            for(int j = 0; j < 7; j++) {
                System.out.print(board[i][j]);
            }
            System.out.println("");
        }
    }

    public LinkedList<Integer>[][] getBoard() {
        return board;
    }

    public void setBoard(LinkedList<Integer>[][] board) {
        this.board = board;
    }
}
