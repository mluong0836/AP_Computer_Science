/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connectfour_micheal_luong;

/**
 *
 * @author micheal
 */

public class Player extends Counters {
    
    private int row; 
    private int col;
    DisplayBoard board = new DisplayBoard();
    
    public Player(String color) {
        super(color);
    }
    
    @Override
    public boolean CheckBound(int[][] board) {
        return true;
    }
    
    @Override
    public void addCounter(int column) {
        
    }
    
    @Override
    public void CheckWin() {
        
    }
    
    @Override
    public int getRow() {
        return this.row;
    }
    
    @Override
    public int getCol() {
        return this.col;
    }
}
