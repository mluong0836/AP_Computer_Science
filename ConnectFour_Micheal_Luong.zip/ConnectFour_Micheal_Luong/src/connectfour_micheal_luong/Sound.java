/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connectfour_micheal_luong;

    import java.io.File;
    import java.io.FileInputStream;
    import java.io.FileNotFoundException;
    import java.io.IOException;
    import java.io.InputStream;
    import sun.audio.AudioPlayer;
    import sun.audio.AudioStream;

/**
 *
 * @author micheal
 */

public class Sound {
    
    public static AudioStream as;
    
    public static void Init(int type) throws FileNotFoundException, IOException {
        if(type == 1) {
            InputStream in = new FileInputStream(new File("music/dropSound.wav"));
            AudioStream dropCounter = new AudioStream(in); 
            Sound.as = dropCounter;
        } else if(type == 2) {
            InputStream in = new FileInputStream(new File("music/notValid.wav"));
            AudioStream notValid = new AudioStream(in);
            Sound.as = notValid;
        } else if(type == 3) {
            InputStream in = new FileInputStream(new File("music/Win.wav"));
            AudioStream win = new AudioStream(in);
            Sound.as = win;
        } else if(type == 4) {
            InputStream in = new FileInputStream(new File("music/Lose.wav"));
            AudioStream lose = new AudioStream(in);
            Sound.as = lose;
        }
    }
    
    public void Start() {
        AudioPlayer.player.start (as);
    }
    
    public void Stop() {
        AudioPlayer.player.stop (as);
    }
}
