/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connectfour_micheal_luong;

/**
 *
 * @author micheal
 */
public class Computer extends Counters {

    int row;
    int col;

    public Computer(String color) {
        super(color);
    }

    @Override
    public boolean CheckBound(int[][] board) {
        return true;
    }

    @Override
    public void addCounter(int column) {

    }

    @Override
    public void CheckWin() {

    }

    @Override
    public int getRow() {
        return this.row;
    }

    @Override
    public int getCol() {
        return this.col;
    }
}
