/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connectfour_micheal_luong;

/**
 *
 * @author micheal
 */
public interface Interaction {
    public boolean CheckBound(int[][] board);
    public void addCounter(int column);
    public void CheckWin();//checks for any win conditions
    public int getRow();
    public int getCol();
}
