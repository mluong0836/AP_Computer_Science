/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connectfour_micheal_luong;
    import java.util.Scanner;
/**
 *
 * @author micheal
 */
public class GamePlay extends DisplayBoard {
    private boolean loop = true;
    
    public void Gameloop(int choice) {
        int answer;
        
        Scanner scan = new Scanner(System.in);
        
        while(loop) {
            System.out.println("Pick a column from 1 through 7 to drop your counter.");
            System.out.println("If you want to quit, press the number 0.");
            answer = scan.nextInt() - 1;
        }
        
        if(choice == 2) {//best out of three
            /*reset the gameboard*/
            this.Reset();
        }
    }

    public void setLoop(boolean loop) {
        this.loop = loop;
    }
}
