/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mazesearch_micheal_luong_part2;

    import java.util.LinkedList;
    import java.util.Random;

/**
 *
 * @author micheal
 */

public class Maze {
    
    private final int tried = 3;
    private final int path = 7;
    Random rand = new Random();
    
    int row = 8;
    int col = 13;
    int[][] grid = new int[row][col];
    
    public void create() {
        for(int i = 0; i < row; i++) {
            for(int j = 0; j < col; j++) {
                grid[i][j] = rand.nextInt(2);
            }
        }
        
        print();
        if(Traverse(0, 0)) {
            System.out.println("wprls");
        } else {
            System.out.println("nope");
            create();
        }
    }
    
    public void print() {
        for(int i = 0; i < row; i++) {
            for(int j = 0; j< col; j++) {
                System.out.print(grid[i][j]);
            }
            System.out.println("");
        }
    }
    
    public boolean Traverse(int row, int column) {

        boolean finish = false;
        
        if(Valid(row, column)) {
            grid[row][column] = tried;
        
            /*ends when the last location of the 2d array is located*/
            if(row == grid.length - 1 && column == grid[0].length - 1) {
                finish = true;
            } else {
            
                /*path checks the path in front(down)*/
                finish = Traverse(row+1, column);
                
                if(!finish) {//path checks the right path
                    finish = Traverse(row, column+1);
                }
            
                 if(!finish) {//path checks the path behind (up)
                    finish = Traverse(row-1, column);
                }
                
                if(!finish) {//path checks the left path
                    finish = Traverse(row, column-1);
                }               
            }
                
            /*if the boolean finish is true, then the correct pathway will be marked with a 7*/
            if(finish) {
                grid[row][column] = path;//marks correct
            }
        }
        
        System.out.println("\n\n\n\n\n\n\n");
        print();
        return finish;
    }
    
    private boolean Valid(int row, int column) {
        boolean end = false;
        
        /*Checks boundaries*/
        if(row >= 0 && row < grid.length && column >= 0 && column < grid[row].length) {
            
            /*if there is an open path that isn't blocked by walls represented by zeros*/
            if(grid[row][column] == 1) {
                end = true;
            }
        }
        return end;
    }
    
}